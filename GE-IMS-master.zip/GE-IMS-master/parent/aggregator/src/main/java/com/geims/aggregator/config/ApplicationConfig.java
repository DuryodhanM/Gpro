package com.geims.aggregator.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.geims.aggregator.controller.AggregatorService;

@Configuration
@ComponentScan(basePackageClasses = {AggregatorService.class})
public class ApplicationConfig {
	@Bean
	public RestTemplate restTemplate(){
		return new RestTemplate();
	}
	
}
