package com.geims.aggregator.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.geims.aggregator.vo.AssemblyLoginVo;
import com.geims.aggregator.vo.CategoryVo;
import com.geims.aggregator.vo.ItemVo;
import com.geims.aggregator.vo.LoginVo;
import com.geims.aggregator.vo.MasterLoginVo;
import com.geims.aggregator.vo.ReceiveInventory;
import com.geims.aggregator.vo.SendInfo;
import com.geims.aggregator.vo.WarehouseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "Aggregator")
@RestController
@CrossOrigin
@RequestMapping(value = "/")
public class AggregatorService {

	@Autowired
	private RestTemplate restTemplate;

	@ApiOperation(value = "Post Login data", notes = "Save User login data")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "User data cannot be posted"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/login", consumes = "application/json", produces = "application/json", method = RequestMethod.POST)
	public @ResponseBody LoginVo login(@RequestBody LoginVo loginVo) {
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		MasterLoginVo masterLoginVo = new MasterLoginVo();
		AssemblyLoginVo assemblyLoginVo = new AssemblyLoginVo();
		try {
			restTemplate.setMessageConverters(messageConverters);
			masterLoginVo = restTemplate.postForObject("http://localhost:2002/login", loginVo,
					MasterLoginVo.class);
			assemblyLoginVo = restTemplate.postForObject("http://localhost:2006/login", loginVo,
					AssemblyLoginVo.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			loginVo.setUserName("");
			loginVo.setPassword("");
			restTemplate.postForLocation("http://localhost:2002/logout", loginVo);
			restTemplate.postForLocation("http://localhost:2006/logout", loginVo);
			return loginVo;
		}
		if ((masterLoginVo.isAuthenticated() == true) && (assemblyLoginVo.isAuthenticated() == true)) {
			loginVo.setPassword("");
		} else {
			loginVo.setPassword("");
			loginVo.setUserName("");
		}
		return loginVo;
	}

	@ApiOperation(value = "Logout User", notes = "Log out the user successfully")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "User Cannot be logged out"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/logout", consumes = "application/json", method = RequestMethod.POST)
	public void logout(@RequestBody LoginVo loginVo) {
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		restTemplate.postForLocation("http://localhost:2002/logout", loginVo);
		restTemplate.postForLocation("http://localhost:2006/logout", loginVo);
	}

	@ApiOperation(value = "Post Warehouse Data", notes = "Post Warehouse Data to map with master data")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Warehouse data cannot be posted"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "update/warehouse", consumes = "application/json", method = RequestMethod.POST)
	public void createWarehouse(@RequestBody WarehouseVo warehouseVo) {
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		restTemplate.postForLocation("http://localhost:2002/put/warehouse", warehouseVo);
	}

	@ApiOperation(value = "Post Inventory item Data", notes = "Post Inventory item Data to map with master data")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Item data cannot be posted"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "update/item", consumes = "application/json", method = RequestMethod.POST)
	public void createItem(@RequestBody ItemVo itemVo) {
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		restTemplate.postForLocation("http://localhost:2002/put/item", itemVo);
	}

	@ApiOperation(value = "Post Rfid tag Data", notes = "Post Rfid tag Data to map with master data")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Tag data cannot be posted"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "update/tag", consumes = "application/json", method = RequestMethod.POST)
	public void createTag(@RequestBody SendInfo sendInfo) {
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		restTemplate.postForLocation("http://localhost:2002/put/tag", sendInfo);
	}

	@ApiOperation(value = "Post Category Data", notes = "Post Category Data to map with master data")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Category data cannot be posted"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "update/category", consumes = "application/json", method = RequestMethod.POST)
	public void createCateogry(@RequestBody CategoryVo categoryVo) {
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		restTemplate.postForLocation("http://localhost:2002/put/category", categoryVo);
	}

	@ApiOperation(value = "Post inventory Data", notes = "Post inventory Data")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Category data cannot be posted"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "update/inventory", consumes = "application/json", method = RequestMethod.POST)
	public void updateInventoryDetails(@RequestBody SendInfo receiveInventory) {
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		restTemplate.postForObject("http://localhost:2002/get", receiveInventory, ReceiveInventory.class);
	}

	/*@RequestMapping(value = "/start", produces = "application/json")
	public void test() {
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		Date date = new Date();
		Date expiryDate = new Date();
		try {
			expiryDate = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH).parse("2025-12-23");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		WarehouseVo warehouseVo = new WarehouseVo();
		warehouseVo.setLocation("Bangalore");
		warehouseVo.setWarehouseName("warehouse 1");
		CategoryVo categoryVo = new CategoryVo();
		categoryVo.setCategory("Mechanical");
		categoryVo.setId(1);
		ItemVo itemVo = new ItemVo();
		itemVo.setCategoryId(1);
		itemVo.setId(1);
		itemVo.setItemName("Piston");
		SendInfo sendInfo = new SendInfo();
		sendInfo.setInTime(date);
		sendInfo.setExpiryDate(expiryDate);
		sendInfo.setItemId(1);
		sendInfo.setMfgDate(date);
		sendInfo.setOutTime(null);
		sendInfo.setRfid("x01x812x342");
		sendInfo.setWarehouseId(1);
		restTemplate.postForLocation("http://localhost:2002/put/warehouse", warehouseVo);
		restTemplate.postForLocation("http://localhost:2002/put/category", categoryVo);
		restTemplate.postForLocation("http://localhost:2002/put/item", itemVo);
		restTemplate.postForLocation("http://localhost:2002/put/tag", sendInfo);
		restTemplate.postForObject("http://localhost:2002/get", sendInfo, ReceiveInventory.class);
	}*/
}
