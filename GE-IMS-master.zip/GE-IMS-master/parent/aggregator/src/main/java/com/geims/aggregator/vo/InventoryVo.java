package com.geims.aggregator.vo;

import java.util.Date;

public class InventoryVo {
	private int id;
	private WarehouseVo warehouse;
	private Date inTime;
	private Date outTime;
	private int status;
	private TagVo tagDetails;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public WarehouseVo getWarehouse() {
		return warehouse;
	}
	public void setWarehouse(WarehouseVo warehouse) {
		this.warehouse = warehouse;
	}
	public Date getInTime() {
		return inTime;
	}
	public void setInTime(Date inTime) {
		this.inTime = inTime;
	}
	public Date getOutTime() {
		return outTime;
	}
	public void setOutTime(Date outTime) {
		this.outTime = outTime;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public TagVo getTagDetails() {
		return tagDetails;
	}
	public void setTagDetails(TagVo tagDetails) {
		this.tagDetails = tagDetails;
	}
}
