package com.geims.aggregator.vo;

public class ReceiveInventory {
	private InventoryVo inventoryDetails;

	public InventoryVo getInventoryDetails() {
		return inventoryDetails;
	}

	public void setInventoryDetails(InventoryVo inventoryDetails) {
		this.inventoryDetails = inventoryDetails;
	}
}
