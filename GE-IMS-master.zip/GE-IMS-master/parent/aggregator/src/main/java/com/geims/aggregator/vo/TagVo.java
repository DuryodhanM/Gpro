package com.geims.aggregator.vo;

import java.util.Date;


public class TagVo {
	private int id;
	private String rfid;
	private ItemEntityVo item;
	private Date manufactureDate;
	private Date expiryDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRfid() {
		return rfid;
	}
	public void setRfid(String rfid) {
		this.rfid = rfid;
	}	
	public ItemEntityVo getItem() {
		return item;
	}
	public void setItem(ItemEntityVo item) {
		this.item = item;
	}
	public Date getManufactureDate() {
		return manufactureDate;
	}
	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	} 
}
