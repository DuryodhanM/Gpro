var app = angular.module("InventoryManagement",['ngRoute',"chart.js"]);
var target = "http://localhost:8761";
app.config(['$routeProvider',function($routeProvider){
	$routeProvider.when('/dashboard',{
		templateUrl: 'templates/dashboard.html',
		controller:'dashboard-controller'
	})
	.when('/booking',{
		templateUrl: 'templates/buildAndSave.html',
		controller:'booking-controller'
	})
	.when('/login',{
		templateUrl:'templates/login.html',
		controller:'login-controller'
	})
	.when('/billing',{
		templateUrl:'templates/billing.html',
		controller:'billing-controller'
	})
	.when('/reports/avail',{
		templateUrl:'templates/org-avail.html',
		controller:'org-avail-controller'
	})
	.when('/reports/aging',{
		templateUrl:'templates/aging.html',
		controller:'aging-controller-reports'
	})
	.when('/value',{
		templateUrl:'templates/value.html',
		controller:'value-controller'
	})
	.when('/search',{
		templateUrl:'templates/search.html',
		controller:'search-controller'
	})
	.otherwise({
		redirectTo:'/login'
	});
}]);
app.controller('login-controller',function($scope,$http,$window,$location){
	$scope.userName = "";
	$scope.password = "";
	$scope.submit = function(){
		$http({
			method:"post",
			url:target+"/login",
			data:{userName:$scope.userName,password:$scope.password}
		}).then(function(response){
			if(response.data.userName!=""){
				var data = response.data;
				data.password = "";
				$window.sessionStorage.setItem("login",JSON.stringify(data));
				$window.sessionStorage.setItem("status","0");
				$location.path("/dashboard");
			}

		});
	};
});
app.controller('search-controller',function($scope,$http,$window){
	$scope.warehouse;
	$scope.category;
	$scope.itemName;
	$scope.partNumber;
	$scope.error="";
	$scope.searchValue;
	$scope.selectedFilter;
	$scope.items=[];
	$scope.results=[];
	$scope.propertyName = 'itemName';
	  $scope.reverse = false;
	  $scope.sortBy = function(propertyName) {
		    $scope.reverse = ($scope.propertyName === propertyName) ? !$scope.reverse : false;
		    $scope.propertyName = propertyName;
		  };
	$http({
		method:"post",
		url:"http://localhost:2003/get/all/"+JSON.parse($window.sessionStorage.getItem("login")).userName,
		data:{warehouse:undefined,partNumber:undefined,itemName:undefined,category:undefined}
	}).then(function(response){
		$scope.items = response.data;
		$scope.results = $scope.items;
		if($scope.results.length == 0){
			$scope.error = "No Items Found!";
		}
		else 
			$scope.error ="";
	});
	$scope.filter = function(){
		if($scope.warehouse == "")
			$scope.warehouse = undefined;
		if($scope.category == ""){
			$scope.category = undefined;
		}
		if(angular.isUndefined($scope.itemName)){
			var newitem = undefined;
		}
		else{
			var newitem = $scope.itemName.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
			
		}
				//console.log({warehouse:$scope.warehouse,partNumber:$scope.partNumber,itemName:$scope.itemName,category:$scope.category});
		$http({
			method:"post",
			url:"http://localhost:2003/get/all/"+JSON.parse($window.sessionStorage.getItem("login")).userName,
			data:{warehouse:$scope.warehouse,partNumber:$scope.partNumber,itemName:newitem,category:$scope.category}
		}).then(function(response){
			$scope.results = response.data;
			if($scope.results.length == 0){
				$scope.error = "No Items Found!";
			}
			else 
				$scope.error ="";
		});
	}
	$scope.search = function(){
		if($scope.selectedFilter==""){
			$scope.results=[];
			var newstr = $scope.searchValue.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
			angular.forEach($scope.items,function(value,key){
			if((value.itemName.includes(newstr))||(value.partNumber==parseInt(newstr))||(value.warehouse.includes(newstr))||(value.category.includes(newstr))){
				$scope.results.push(value);
			}
			});
			if($scope.results.length == 0){
				$scope.error = "Nothing Found!";
			}
			else 
				$scope.error ="";
		}
		else if($scope.selectedFilter=="Item Name"){
			$scope.results=[];
			angular.forEach($scope.items,function(value,key){	
				var newstr = $scope.searchValue.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
			if(value.itemName.includes(newstr)){
				$scope.results.push(value);
			}
			});
			if($scope.results.length == 0){
				$scope.error = "No Items Found!";
			}
			else 
				$scope.error ="";
		}
		else if($scope.selectedFilter=="Part Number"){
			$scope.results=[];
			angular.forEach($scope.items,function(value,key){
				console.log(value.partNumber);
				console.log($scope.searchValue);
				var newstr = $scope.searchValue.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
			if(value.partNumber==parseInt(newstr)){
				$scope.results.push(value);
			}
			});
			if($scope.results.length == 0){
				$scope.error = "No Items Found!";
			}
			else 
				$scope.error ="";
		}
		else if($scope.selectedFilter=="Warehouse"){
			$scope.results=[];
			angular.forEach($scope.items,function(value,key){
				var newstr = $scope.searchValue.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
			if(value.warehouse.includes(newstr)){
				$scope.results.push(value);
			}
			});
			if($scope.results.length == 0){
				$scope.error = "No Items Found!";
			}
			else 
				$scope.error ="";
		}
		else {
			$scope.results=[];
			angular.forEach($scope.items,function(value,key){
				var newstr = $scope.searchValue.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
			if(value.category.includes(newstr)){
				$scope.results.push(value);
			}
			});
			if($scope.results.length == 0){
				$scope.error = "No Items Found!";
			}
			else 
				$scope.error ="";
		}
	}
	$scope.display = function(){
		if($scope.results.length==0)
			return false;
		else 
			return true;
	}
});
app.controller('booking-controller',function($scope,$http,$window){
	$scope.data = []
	$scope.selectedValue = 0;
	$scope.quantity = [];
	$scope.input = []
	$http({
		method:"post",
		url:"http://localhost:2006/",
		data:JSON.parse($window.sessionStorage.getItem("login"))
	}).then(function(response){
		$scope.data = response.data;
		console.log($scope.data);
		$scope.parts = $scope.data[$scope.selectedValue].partNumberList;
	});
	$scope.func = function(){
		$scope.parts = $scope.data[$scope.selectedValue].partNumberList;
	}	
	$scope.plantAndsave = function(){
		console.log($scope.data[$scope.selectedValue]);
		$window.sessionStorage.setItem("assembly",JSON.stringify($scope.data[$scope.selectedValue]));
	}

});
app.controller('billing-controller',function($scope,$window,$http){
	$scope.y =  [];
	$scope.y = JSON.parse($window.sessionStorage.getItem("assembly")).partNumberList;
	console.log($scope.y);
	$scope.data = [];
	$scope.bookingNumber;
	$scope.total = 0;
	for(var i =0;i<$scope.y.length;i++){
		var temp = {category:$scope.y[i].category,quantity:$scope.y[i].recomendedQuantity,partNumber:$scope.y[i].partNumber,price:0};
		$scope.data.push(temp);
	}
	$scope.confirm = function(){
		$http({
			method:"post",
			url:"http://localhost:2006/book/"+JSON.parse($window.sessionStorage.getItem("login")).userName,
			data:JSON.parse($window.sessionStorage.getItem("assembly"))
		}).then(function(response){
			$window.sessionStorage.setItem("assembly","");
			$scope.bookingNumber = response.data[response.data.length-1]-1;
			for(var i = 0;i<response.data.length-1;i++){
				$scope.total+=response.data[i];
			}
		});
	}
	/*$http({
		method:"post",
		url:"http://localhost:2006/book/"+JSON.parse($window.sessionStorage.getItem("login")).userName,
		data:JSON.parse($window.sessionStorage.getItem("assembly"))
	}).then(function(response){
		console.log(response.data);
	});*/
})
app.controller('dashboard-controller',function($scope,$window,$http,$filter,$sce){
	if($window.sessionStorage.getItem("status") == "0"){
		$scope.aging = "http://localhost:2004";
		$scope.name = JSON.parse($window.sessionStorage.getItem("login")).userName;
		$scope.bookingId = "";
		$scope.booking = [];
		$scope.data = [];
		$scope.labels = [];
		var temp = [];
		$http({
			method:"post",
			url:$scope.aging+"/graph",
			data:JSON.parse($window.sessionStorage.getItem("login"))
		}).then(function(response){
			var data = response.data.graphData;
			$scope.name = JSON.parse($window.sessionStorage.getItem("login")).userName;
			for(var i =0;i<data.length;i++){
				$scope.data.push(data[i].quantity);
				if(data[i].age>90)
					$scope.labels.push("above 90");
				else if(data[i].age>60)
					$scope.labels.push("60-90");
				else if(data[i].age>40)
					$scope.labels.push("40-60");
				else
					$scope.labels.push("0-40");
			}
		});
		$scope.downloadAging = function(){
			var fileName = "test.pdf";
            var a = document.createElement("a");
            document.body.appendChild(a);
            a.style = "display: none";
			$http({
				method:"post",
				url:$scope.aging+"/download",
				data:JSON.parse($window.sessionStorage.getItem("login")),
				responseType:'arraybuffer'
			}).then(function(response){
				var file = new Blob([response.data],{type:"application/pdf"});
				var fileUrl = URL.createObjectURL(file);
				a.href = fileUrl;
                a.download = fileName;
                a.click();				
			});
		}
		$scope.series = ["Aging of Items",""];
		$scope.options = {
				legend:{display:false},
				scales: {
					yAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'Quantity'
						},
						ticks: {
							beginAtZero:true
						}
					}],
					xAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'Age group (in percentage of life spent)'
						},
						ticks: {
							beginAtZero:true
						}
					}]

				}
		};
		$scope.data1 = [];
		$scope.labels1 = [];
		$scope.tempo = [];
		$scope.ordered = [];
		$scope.orderedValue = [];
		$http({
			method:"post",
			url:"http://localhost:2003/global",
			data:JSON.parse($window.sessionStorage.getItem("login"))
		}).then(function(response){
			var data = response.data;
			for(var i=0;i<data.length;i++){
				var qty = 0;
				var val = 0;
				for(var j =0;j<data[i].quantity.length;j++){
					qty+=data[i].quantity[j];
					val+=data[i].value[j];
				}	
				$scope.tempo.push({name:data[i].itemName,quantity:qty,value:val});
			}
			$scope.ordered = $filter('orderBy')($scope.tempo,'quantity',true);
			$scope.orderedValue = $filter('orderBy')($scope.tempo,'value',true);
			var b = 0;
			if($scope.tempo.length > 9)
				b = 9;
			else
				b = $scope.tempo.length;
			for(var i =0;i<b;i++){
				$scope.data1.push($scope.ordered[i].quantity);
				$scope.labels1.push($scope.ordered[i].name);
			}
		});
		var label = 'Quantity(in thousand units)';
		$scope.availValue = function(){
			$scope.data1 = [];
			$scope.labels1 = [];
			label = 'Value';
			b = 0;
			if($scope.tempo.length > 9)
				b = 9;
			else
				b = $scope.tempo.length;
			for(var i =0;i<b;i++){
				$scope.data1.push($scope.orderedValue[i].value);
				$scope.labels1.push($scope.orderedValue[i].name);
			}
		}
		$scope.availQuantity = function(){
			$scope.data1 = [];
			$scope.labels1 = [];
			var b = 0;
			label = 'Quantity'
			if($scope.tempo.length > 9)
				b = 9;
			else
				b = $scope.tempo.length;
			for(var i =0;i<b;i++){
				$scope.data1.push($scope.ordered[i].quantity);
				$scope.labels1.push($scope.ordered[i].name);
			}
		}
		$scope.options1 = {
				legend:{display:false},
				scales: {
					yAxes: [{
						scaleLabel: {
							display: true,
							labelString: label
						},
						ticks: {
							beginAtZero:true
						}
					}],
					xAxes: [{
						scaleLabel: {
							display: false,
							labelString: 'Warehouse Names'
						},
						ticks: {
							beginAtZero:true
						}
					}]

				}
		};
		
	}
	$scope.logout = function(){
		$http({
			method:"post",
			url:target+"/logout",
			data:JSON.parse($window.sessionStorage.getItem("login"))
		}).then(function(){
			$window.sessionStorage.setItem("login","");
			$window.sessionStorage.setItem("status","1");
		});

	}
	$scope.getBooking = function(){
		if($scope.bookingId != ""){
			$http({
				method:"get",
				url:"http://localhost:2006/get/booking/"+JSON.parse($window.sessionStorage.getItem("login")).userName+"/"+$scope.bookingId
			}).then(function(response){
				$scope.booking = response.data;
			});
		}
	}
});
app.controller('value-controller',function($scope,$window){
	if($window.sessionStorage.getItem("status") == "0"){
		$scope.data = [
		               [80,200,150],
		               [30,65,50],
		               [10,50,20]
		               ];
		$scope.labels = ["warehouse-1","warehouse-2","warehouse-3"];
		$scope.series = ['A', 'B','C'];
		$scope.options = {
				legend:{display:true},
				scales: {
					yAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'value (in million $)'
						},
						ticks: {
							beginAtZero:true
						}
					}]
				}
		};
	}
});
app.controller('case-controller',function($scope,$window){
	if($window.sessionStorage.getItem("status") == "0"){
		$scope.data = [
		               [600,500,400,450,380,900],
		               [580,450,400,480,420,800]
		               ];
		$scope.labels = ["May-16","Jun-16","Jul-16","Aug-16","Sep-16","Oct-16"];
		$scope.series = ["Cases Ordered","Cases Shipped"];
		$scope.options = {
				legend:{display:true},
				scales: {
					yAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'Quantity'
						},
						ticks: {
							beginAtZero:true
						}
					}],
					xAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'Monthly Updates'
						},
						ticks: {
							beginAtZero:true
						}
					}]

				}
		};
	}
});
app.controller('work-accuracy',function($scope,$window){
	if($window.sessionStorage.getItem("status") == "0"){
		$scope.data = [600,500,400,450,380,900];
		$scope.labels = ["May-16","Jun-16","Jul-16","Aug-16","Sep-16","Oct-16"];
		$scope.options = {
				legend:{display:false},
				scales: {
					yAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'Percentage'
						},
						ticks: {
							beginAtZero:true
						}
					}],
					xAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'Months'
						}
					}]

				}
		};
	}
});
app.controller('avail-controller',function($scope,$http,$window){
	$scope.data = [];
	$scope.labels = [];
	$scope.store = [];
	$http({
		method:"post",
		url:"http://localhost:2003/global",
		data:$window.sessionStorage.getItem("login")
	}).then(function(response){
		var data = response.data;
		$scope.store = data;
		if(data.length <10){
			for(var i=0;i<data.length;i++){
				var qty = 0;
				$scope.labels.push(data[i].itemName);
				for(var j =0;j<data[i].quantity.length;j++){
					qty+=data[i].quantity[j];
				}
				$scope.data.push(qty);			
			}
		}
		else{
			for(var i=0;i<10;i++){
				var qty = 0;
				$scope.labels.push(data[i].itemName);
				for(var j =0;j<data[i].quantity.length;j++){
					qty+=data[i].quantity[j];
				}
				$scope.data.push(qty);			
			}
		}
	});
	$scope.options = {
			legend:{display:true},
			scales: {
				yAxes: [{
					scaleLabel: {
						display: true,
						labelString: 'Quantity(in thousand units)'
					},
					ticks: {
						beginAtZero:true
					}
				}],
				xAxes: [{
					scaleLabel: {
						display: true,
						labelString: 'Warehouse Names'
					},
					ticks: {
						beginAtZero:true
					}
				}]

			}
	};
});
app.controller('status_info', function($scope,$window){
	if($window.sessionStorage.getItem("status") == "0"){
		$scope.status = [" In Progress", "Open", "Paid"];
	}
});

app.controller('value-controller',function($scope,$window){
	if($window.sessionStorage.getItem("status") == "0"){
		$scope.data = [
		               [80,200,150],
		               [30,65,50],
		               [10,50,20]
		               ];
		$scope.labels = ["warehouse-1","warehouse-2","warehouse-3"];
		$scope.series = ['A', 'B','C'];
		$scope.options = {
				legend:{display:true},
				scales: {
					yAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'value (in million $)'
						},
						ticks: {
							beginAtZero:true
						}
					}]
				}
		};
	}
});
app.controller('org-avail-controller',function($scope,$http,$window,$filter){
	$scope.data = [];
	$scope.temp = [];
	$scope.start = 0;
	$scope.end = 10;
	$scope.labels = [];
	var receive = [];
	$http({
		method:"post",
		url:"http://localhost:2003/global",
		data:JSON.parse($window.sessionStorage.getItem("login"))
	}).then(function(response){
		var data = response.data;
		for(var i=0;i<data.length;i++){
			var qty = 0;
			for(var j =0;j<data[i].quantity.length;j++){
				qty+=data[i].quantity[j];
			}
			receive.push({itemName:data[i].itemName,quantity:qty});
			$scope.temp = $filter('orderBy')(receive,'quantity',true);
		}
		for(var i =0;i<$scope.temp.length;i++){
			if(i<10){
				$scope.data.push(parseInt($scope.temp[i].quantity));
				$scope.labels.push($scope.temp[i].itemName);
			}
			else{
				break;
			}
		}
	});
	$scope.options = {
			scales: {
				yAxes: [{
					scaleLabel: {
						display: true,
						labelString: 'Quantity(no. of units)'
					},
					ticks: {
						beginAtZero:true
					}
				}],
				xAxes:[{
					scaleLabel: {
						display: true,
						labelString: 'Items'
					}
				}]
			}
	};

	$scope.next = function(){
		$scope.data = [];
		$scope.labels = [];
		console.log($scope.temp);
		if($scope.end + 10 > $scope.temp.length){
			$scope.end = $scope.temp.length;
		}
		else{
			$scope.start += 10;
			$scope.end += 10;
		}
		for( var i = $scope.start; i < $scope.end ; i++){
			$scope.data.push(parseInt($scope.temp[i].quantity));
			$scope.labels.push($scope.temp[i].itemName);
		}
	}
	$scope.previous = function(){
		$scope.data = [];
		$scope.labels = [];
		if($scope.start - 10 < 0){
			$scope.start = 0;
		}
		else{
			$scope.start -= 10;
			$scope.end -= 10;
		}
		for( var i = $scope.start; i < $scope.end ; i++){
			$scope.data.push(parseInt($scope.temp[i].quantity));
			$scope.labels.push($scope.temp[i].itemName);
		}
	}
	$scope.target = target;
});
app.controller('aging-controller',function($scope,$http,$window){
		$scope.data = [];
		$scope.labels = [];
		var temp = [];
		$http({
			method:"post",
			url:"http://localhost:2004/global",
			data:$window.sessionStorage.getItem("login")
		}).then(function(response){
			var data = response.data.graphData;
			for(var i =0;i<data.length;i++){
				$scope.data.push(data[i].quantity);
				if(data[i].age>90)
					$scope.labels.push("above 90");
				else if(data[i].age>60)
					$scope.labels.push("60-90");
				else if(data[i].age>40)
					$scope.labels.push("40-60");
				else
					$scope.labels.push("0-40");
			}
		});
		$scope.series = ["Aging of Items",""];
		$scope.options = {
				legend:{display:false},
				scales: {
					yAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'Quantity'
						},
						ticks: {
							beginAtZero:true
						}
					}],
					xAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'Age group (in percentage of life spent)'
						},
						ticks: {
							beginAtZero:true
						}
					}]

				}
		};
});

app.controller('aging-controller-reports',function($scope,$http){
		$scope.target = target;
		var temp;
		var midA=0;
		$scope.data = [];
		$scope.labels = [];
		var midB=0;
		var old=0;
		$http({
			method:"get",
			url:"http://localhost:2004/global"
		}).then(function(response){
			temp = response.data;
			angular.forEach(temp,function(value,key){
				if(parseInt(value.age)>90){
					$scope.data.push(parseInt(value.itemsListVO.length));
					$scope.labels.push(value.itemName + "(<=10)");
				}
				else if(parseInt(value.age)>70){
					midA=midA+parseInt(value.itemsListVO.length);
				}
				else if(parseInt(value.age)>40){
					midB=midB+parseInt(value.itemsListVO.length);
				}
				else{
					old=old+parseInt(value.itemsListVO.length);
				}
			});
			$scope.data.push(midA);
			$scope.data.push(midB);
			$scope.data.push(old);
			$scope.labels.push("30-10");
			$scope.labels.push("60-30");
			$scope.labels.push(">60");
		});
		$scope.options = {
				scales: {
					yAxes: [{
						scaleLabel: {
							display: true,
							labelString: 'Quantity'
						},
						ticks: {
							beginAtZero:true
						}
					}],
					xAxes:[{
						scaleLabel: {
							display: true,
							labelString: 'Shelf life remaining(in percentage)'
						}
					}]
				}
		};
});
