package com.geIms.assembly.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@EntityScan(basePackages= {"com.geIms.assembly.entity"})
@EnableJpaRepositories("com.geIms.assembly.dao")/*
@ComponentScan(basePackageClasses={AssemblyServiceImpl.class,Controller.class})*/
@ComponentScan(basePackages={"com.geIms.assembly.service","com.geims.assembly.serviceImpl","com.geims.assembly.controller"})
public class AppConfig {

}
