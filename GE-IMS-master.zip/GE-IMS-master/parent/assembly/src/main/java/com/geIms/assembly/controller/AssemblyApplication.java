package com.geIms.assembly.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 
 * @author Vishal Verma
 * @author $LastChangedBy: Vivek Bengre
 * @version $Revision:001 $, $Date: 19/10/2016
 */

@EnableSwagger2
@SpringBootApplication
@ComponentScan(basePackages={"com.geIms.assembly.config"})
public class AssemblyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(AssemblyApplication.class, args);
	}

}
