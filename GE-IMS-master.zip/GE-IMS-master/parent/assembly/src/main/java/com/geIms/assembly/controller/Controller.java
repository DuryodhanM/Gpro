package com.geIms.assembly.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.geIms.assembly.service.AssemblyService;
import com.geIms.assembly.vo.AssemblyLoginVo;
import com.geIms.assembly.vo.AssemblyVo;
import com.geIms.assembly.vo.LoginVo;
import com.geIms.assembly.vo.ReceiveBookingVo;
import com.geIms.assembly.vo.SendVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * 
 * @author Vishal Verma
 * @author $LastChangedBy: Vivek Bengre
 * @version $Revision:001 $, $Date: 19/10/2016
 */

@Api(value = "Assembly Controller", description = " Provides End assembly data for building an assembly ")
@RestController
@CrossOrigin
public class Controller {
	@Autowired
	private AssemblyService assemblyService;

	@ApiOperation(value = "logs in the user")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "User not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public @ResponseBody AssemblyLoginVo login(@RequestBody LoginVo loginVo) {
		AssemblyLoginVo assemblyLoginVo = new AssemblyLoginVo();
		String username = loginVo.getUserName();
		String password = loginVo.getPassword();
		if (assemblyService.isAuthenticated(username, password) == true) {
			assemblyLoginVo.setAuthenticated(true);
		} else {
			assemblyLoginVo.setAuthenticated(false);
		}
		return assemblyLoginVo;
	}

	@ApiOperation(value = "log the user out")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "User not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/logout", method = RequestMethod.POST, consumes = "application/json")
	public void logout(@RequestBody LoginVo loginVo) {
		String username = loginVo.getUserName();
		assemblyService.logoutUser(username);
	}

	@ApiOperation(value = "get all assemblies information", notes = "Suggests all the assemblies with part numbers for booking a new assembly")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Assembly not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/", method = RequestMethod.POST, produces = "application/json",consumes = "application/json")
	public @ResponseBody List<AssemblyVo> getAllAssemblies(@RequestBody LoginVo loginvo) {
		if (assemblyService.isLoggedIn(loginvo) == true) {
			return assemblyService.getAllAssemblies(loginvo);
		} else
			return null;
	}

	@ApiOperation(value = "Creates and saves the assembly booking information", notes = "Creates and saves the assembly booking information entered from the user")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Resource not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/book/{userName}", method = RequestMethod.POST, produces = "application/json")
	public @ResponseBody int createBooking(@RequestBody ReceiveBookingVo receiveVo,
			@ApiParam(value = "userName", required = true) @PathVariable("userName") String userName) {
		LoginVo loginvo = new LoginVo();
		loginvo.setUserName(userName);
		if (assemblyService.isLoggedIn(loginvo) == true) {
			return assemblyService.createBooking(receiveVo.getAssemblyVo(),receiveVo.getAssemblyDetailsVo(), userName);
		} else
			return -1;
	}

	@ApiOperation(value = "get Saved Booking information for a given user and order Id", notes = "Username and order id are compulsary to fetch booking data")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Assembly not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "get/booking/{username}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<SendVo> getBooking(
			@ApiParam(value = "userName", required = true) @PathVariable("username") String userName) {
		LoginVo loginvo = new LoginVo();
		loginvo.setUserName(userName);
		if (assemblyService.isLoggedIn(loginvo) == true) {
			return assemblyService.getBookingDetails(userName);
		} else
			return null;
	}
	
	@ApiOperation(value = "confirms booking already created", notes = "confirms booking and reduces inventory")
    @ApiResponses(value = {
            @ApiResponse(code = 404, message = "Items not found"),
            @ApiResponse(code = 200, message = "Successful response send"),
            @ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value="/confirmBooking/{userName}/{orderNumber}",method=RequestMethod.POST,consumes="application/json",produces="application/json")
	public @ResponseBody List<Double> getValue(@RequestBody AssemblyVo receiveVo,@ApiParam(name="userName")  @PathVariable("userName")String userName,@ApiParam(name="orderNumber") @PathVariable("orderNumber")int orderNumber){
		return assemblyService.confirmBooking(receiveVo, orderNumber, userName);		
	}
}
