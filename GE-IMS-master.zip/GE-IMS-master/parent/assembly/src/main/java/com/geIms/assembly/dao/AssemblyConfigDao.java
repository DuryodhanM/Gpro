package com.geIms.assembly.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geIms.assembly.entity.AssemblyConfig;

public interface AssemblyConfigDao extends JpaRepository<AssemblyConfig, Long> {
	public AssemblyConfig findByAssemblyName(String bookingName);
}
