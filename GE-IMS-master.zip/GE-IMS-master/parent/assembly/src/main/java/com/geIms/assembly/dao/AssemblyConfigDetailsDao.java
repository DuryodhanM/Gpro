package com.geIms.assembly.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geIms.assembly.entity.AssemblyConfigDetails;

public interface AssemblyConfigDetailsDao extends JpaRepository<AssemblyConfigDetails, Long>{
	public List<AssemblyConfigDetails> findByAssemblyConfig_AssemblyName(String assemblyName);
}
