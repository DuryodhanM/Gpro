package com.geIms.assembly.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geIms.assembly.entity.AssemblyDetails;

public interface AssemblyDetailsDao extends JpaRepository<AssemblyDetails, Long>{
	AssemblyDetails findById(int id);
}
