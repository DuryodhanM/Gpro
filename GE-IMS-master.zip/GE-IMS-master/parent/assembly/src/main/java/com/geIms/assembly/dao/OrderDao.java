package com.geIms.assembly.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geIms.assembly.entity.Order;

public interface OrderDao extends JpaRepository<Order, Long>{
	public Order findByUser_UserNameAndId(String userName, int id);
	public List<Order> findByUser_UserName(String userName);
	public List<Order> findByStatus(int status);
	public Order findById(int id);
}
