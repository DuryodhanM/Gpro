package com.geIms.assembly.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geIms.assembly.entity.OrderDetails;

public interface OrderDetailsDao extends JpaRepository<OrderDetails, Long>{
	public List<OrderDetails> findByOrder_Id(int bookingNumber);
}
