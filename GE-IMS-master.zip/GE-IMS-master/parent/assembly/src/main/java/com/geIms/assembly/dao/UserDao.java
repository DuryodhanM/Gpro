package com.geIms.assembly.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geIms.assembly.entity.User;

public interface UserDao extends JpaRepository<User, Long>{
	public User findByUserName(String userName);
}
