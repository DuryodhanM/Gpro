package com.geIms.assembly.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "assemblyConfig")
public class AssemblyConfig {
	private int id;
	private String assemblyName;
	private List<AssemblyConfigDetails> itemMap;
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "assemblyName",unique=true)
	public String getAssemblyName() {
		return assemblyName;
	}
	public void setAssemblyName(String assemblyName) {
		this.assemblyName = assemblyName;
	}
		
	@OneToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL,mappedBy = "assemblyConfig")
	public List<AssemblyConfigDetails> getItemMap() {
		return itemMap;
	}
	public void setItemMap(List<AssemblyConfigDetails> itemMap) {
		this.itemMap = itemMap;
	}
}
