package com.geIms.assembly.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "assemblyConfigDetails")
public class AssemblyConfigDetails {
	private int id;
	private int partNumber;
	private AssemblyConfig assemblyConfig;
	private int quantity;	
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Column(name ="partNumber")
	public int getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(int partNumber) {
		this.partNumber = partNumber;
	}
	
	@JoinColumn(name = "assemblyConfigId")
	@Fetch(FetchMode.JOIN)
	@ManyToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	public AssemblyConfig getAssemblyConfig() {
		return assemblyConfig;
	}
	public void setAssemblyConfig(AssemblyConfig assemblyConfig) {
		this.assemblyConfig = assemblyConfig;
	}
	
	@Column(name="quantity")
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
