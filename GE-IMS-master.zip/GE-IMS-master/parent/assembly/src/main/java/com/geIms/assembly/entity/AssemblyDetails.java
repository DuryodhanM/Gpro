package com.geIms.assembly.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="assemblyDetails")
public class AssemblyDetails {
	private Integer id;
	private String assemblyName;
	private String assemblyAddress;
	private long contactNumber;
	private String requestedBy;
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	@Column(name = "assemblyName")
	public String getAssemblyName() {
		return assemblyName;
	}
	public void setAssemblyName(String assemblyName) {
		this.assemblyName = assemblyName;
	}
	
	@Column(name = "assemblyAddress")
	public String getAssemblyAddress() {
		return assemblyAddress;
	}
	public void setAssemblyAddress(String assemblyAddress) {
		this.assemblyAddress = assemblyAddress;
	}
	
	@Column(name = "contactNumber")
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	@Column(name = "requestedBy")
	public String getRequestedBy() {
		return requestedBy;
	}
	public void setRequestedBy(String requestedBy) {
		this.requestedBy = requestedBy;
	}
}
