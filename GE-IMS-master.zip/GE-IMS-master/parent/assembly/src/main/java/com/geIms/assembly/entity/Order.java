package com.geIms.assembly.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "orderMaster")
public class Order {
	private int id;
	private AssemblyConfig assemblyConfig;
	private User user;
	private Date date;
	private int status;
	private AssemblyDetails assemblyDetails;
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@OneToOne(fetch=FetchType.LAZY,cascade = CascadeType.ALL)
	@JoinColumn(name = "assemblyConfigId")
	@Fetch(FetchMode.JOIN)
	public AssemblyConfig getAssemblyConfig() {
		return assemblyConfig;
	}
	public void setAssemblyConfig(AssemblyConfig assemblyConfig) {
		this.assemblyConfig = assemblyConfig;
	}
	
	@JoinColumn(name = "userId")
	@ManyToOne(fetch=FetchType.LAZY,cascade= CascadeType.ALL)
	@Fetch(FetchMode.JOIN)
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}	
	
	@JoinColumn(name="assemblyId")
	@ManyToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@Fetch(FetchMode.JOIN)
	public AssemblyDetails getAssemblyDetails() {
		return assemblyDetails;
	}
	public void setAssemblyDetails(AssemblyDetails assemblyDetails) {
		this.assemblyDetails = assemblyDetails;
	}
	
}
