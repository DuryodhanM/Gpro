package com.geIms.assembly.service;

import java.util.List;

import com.geIms.assembly.vo.AssemblyDetailsVo;
import com.geIms.assembly.vo.AssemblyVo;
import com.geIms.assembly.vo.LoginVo;
import com.geIms.assembly.vo.SendVo;

public interface AssemblyService {
	public List<AssemblyVo> getAllAssemblies(LoginVo loginVo);
	public int createBooking(AssemblyVo receiveVo,AssemblyDetailsVo detailsVo,String userName);
	public List<Double> confirmBooking(AssemblyVo receiveVo,int orderNumber,String userName);
	public List<SendVo> getBookingDetails(String userName);
	public boolean isAuthenticated(String username, String password);
	public void logoutUser(String username);
	boolean isLoggedIn(LoginVo loginvo);
}
