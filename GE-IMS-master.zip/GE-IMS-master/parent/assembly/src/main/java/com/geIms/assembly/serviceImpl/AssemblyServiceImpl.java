package com.geIms.assembly.serviceImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.geIms.assembly.dao.AssemblyDetailsDao;
import com.geIms.assembly.dao.AssemblyConfigDao;
import com.geIms.assembly.dao.AssemblyConfigDetailsDao;
import com.geIms.assembly.dao.OrderDao;
import com.geIms.assembly.dao.OrderDetailsDao;
import com.geIms.assembly.dao.UserDao;
import com.geIms.assembly.entity.AssemblyDetails;
import com.geIms.assembly.entity.AssemblyConfig;
import com.geIms.assembly.entity.AssemblyConfigDetails;
import com.geIms.assembly.entity.Order;
import com.geIms.assembly.entity.OrderDetails;
import com.geIms.assembly.entity.User;
import com.geIms.assembly.service.AssemblyService;
import com.geIms.assembly.vo.AssemblyDetailsVo;
import com.geIms.assembly.vo.AssemblyVo;
import com.geIms.assembly.vo.PartNumberVo;
import com.geIms.assembly.vo.QuantityVo;
import com.geIms.assembly.vo.ReceiveGlobalAvail;
import com.geIms.assembly.vo.SendVo;
import com.geIms.assembly.vo.LoginVo;

@Service
public class AssemblyServiceImpl implements AssemblyService {

	@Autowired
	private AssemblyConfigDao bookingDao;

	@Autowired
	private AssemblyConfigDetailsDao bookingItemMapDao;
	
	@Autowired
	private OrderDao orderDao;
	
	@Autowired
	private UserDao userDao;
	
	@Autowired
	private OrderDetailsDao quantityMapDao;
	
	@Autowired
	private AssemblyDetailsDao assemblyDetailsDao;

	@Override
	public List<AssemblyVo> getAllAssemblies(LoginVo loginVo) {
		List<AssemblyConfig> bookings = bookingDao.findAll();
		RestTemplate restTemplate = new RestTemplate();
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(new FormHttpMessageConverter());
		messageConverters.add(new StringHttpMessageConverter());
		messageConverters.add(new MappingJackson2HttpMessageConverter());
		restTemplate.setMessageConverters(messageConverters);
		ResponseEntity<ReceiveGlobalAvail[]> responseEntity = restTemplate.postForEntity("http://localhost:2003/global", loginVo, ReceiveGlobalAvail[].class);
		if(responseEntity==null)
			return null;
		ReceiveGlobalAvail[] objects = responseEntity.getBody();
		List<AssemblyVo> assemblyList = new ArrayList<AssemblyVo>();
		for (AssemblyConfig i : bookings) {
			AssemblyVo assembly = new AssemblyVo();
			// for a named booking only (quantity cannot be changed)
			if (i.getAssemblyName() != null) {
				assembly.setAssemblyName(i.getAssemblyName());
				// find all items by booking name and use the booking item map to get the requirements 
				List<AssemblyConfigDetails> partNumbers = bookingItemMapDao.findByAssemblyConfig_AssemblyName(i.getAssemblyName());
				for (AssemblyConfigDetails j : partNumbers) {
					// set the part number for the vo
					PartNumberVo partVo = new PartNumberVo();
					partVo.setPartNumber(j.getPartNumber());
					int req = j.getQuantity();
					// set the required quantity of the item 
					partVo.setRecomendedQuantity(j.getQuantity());
					int qty = 0;
					for(ReceiveGlobalAvail k : objects){
						if(k.getPartNumber() == partVo.getPartNumber()){
							partVo.setCategory(k.getCategory());
							for(Integer l : k.getQuantity()){
								qty+=l;
							}
							partVo.setTotalQuantity(qty);
							if(req <= qty){
								partVo.setStatus(1);
								partVo.setMessage("");
							}
							else{
								partVo.setStatus(-1);
								partVo.setMessage(req-qty+" part(s) of "+k.getItemName()+" not available");
							}
							break;
						}
					}
					//check availability in various warehouses
					/*for (ReceiveGlobalAvail k : objects) {
						if (k.getPartNumber() == partVo.getPartNumber()) {
							partVo.setWarehouseName(k.getWarehouses());
							partVo.setCategory(k.getCategory());
							for (Integer l : k.getQuantity()) {
								if (req > 0) {
									if (req < l) {
										partVo.add(req);
										req = 0;
									} else {
										partVo.add(l);
										req -= l;
									}
								} else {
									partVo.add(0);
								}
							}
							if (req > 0) {
								partVo.setMessage(" ("+req + " parts of " + k.getItemName() + " not available ) ");
								partVo.setStatus(-1);
							}
							else{
								partVo.setStatus(1);
							}
						}
					}*/
					assembly.addPartNumber(partVo);
				}
				assemblyList.add(assembly);
			}
			else{				
			}
		}
		return assemblyList;
	}

	@Override
	public int createBooking(AssemblyVo receiveVo,AssemblyDetailsVo detailsVo,String userName){
		Date date = new Date();
		User user = userDao.findByUserName(userName);
		if(user == null){
			return -1;
		}
		AssemblyConfig booking = bookingDao.findByAssemblyName(receiveVo.getAssemblyName());
		OrderDetails quantityMap = new OrderDetails();
		for(PartNumberVo i :receiveVo.getPartNumberList()){
			quantityMap.setPartNumber(i.getPartNumber());
			int qty = i.getRecomendedQuantity();
			quantityMap.setQuantity(qty);
		}
		quantityMapDao.save(quantityMap);
		Order order = new Order();
		AssemblyDetails assemblyDetails = new AssemblyDetails();
		assemblyDetails.setAssemblyAddress(detailsVo.getAssemblyAddress());
		assemblyDetails.setAssemblyName(detailsVo.getAssemblyName());
		assemblyDetails.setContactNumber(detailsVo.getContactNumber());
		assemblyDetails.setRequestedBy(detailsVo.getRequestedBy());
		assemblyDetailsDao.save(assemblyDetails);
		order.setAssemblyDetails(assemblyDetailsDao.findAll().get(assemblyDetailsDao.findAll().size()-1));
		order.setAssemblyConfig(booking);
		order.setUser(user);
		order.setStatus(0);
		order.setDate(date);
		quantityMap.setOrder(order);
		orderDao.save(order);
		return (orderDao.findAll().get(orderDao.findAll().size()-1).getId());		
	}
	
	@Override
	public List<Double> confirmBooking(AssemblyVo receiveVo,int orderNumber,String userName) {
			try {				
				RestTemplate restTemplate = new RestTemplate();
				List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
				messageConverters.add(new FormHttpMessageConverter());
				messageConverters.add(new StringHttpMessageConverter());
				messageConverters.add(new MappingJackson2HttpMessageConverter());
				restTemplate.setMessageConverters(messageConverters);
				User user = userDao.findByUserName(userName);
				// role 0 for requesters and role 1 for admin
				if(user == null||user.getRole()!=1||user.getStatus()==0){
					return null;
				}
				ResponseEntity<Double[]> responseEntity = restTemplate.postForEntity("http://localhost:2002/get/item",receiveVo,Double[].class);
				if(responseEntity.getBody()==null)
					return null;
				Order order = orderDao.findById(orderNumber);
				order.setStatus(1);
				orderDao.save(order);
				Double[] objects = responseEntity.getBody();
				List<Double> costList = new ArrayList<Double>();
				for(int i=0;i<objects.length;i++){				
					costList.add(objects[i]);
				}
				return costList;
			} catch (RestClientException e) {
				e.printStackTrace();
				return null;
			}
	}

	@Override
	public List<SendVo> getBookingDetails(String userName) {
		List<Order> orders = null;
		if(userDao.findByUserName(userName).getRole()==1)
			orders = orderDao.findByStatus(0);
		else 
			orders = orderDao.findByUser_UserName(userName);
		List<SendVo> sendList = new ArrayList<SendVo>();
		for(Order order : orders){
			SendVo send = new SendVo();
			send.setBookingId(order.getAssemblyConfig().getId());
			send.setBookingName(order.getAssemblyConfig().getAssemblyName());
			send.setOrderId(order.getId());
			send.setUserName(userName);
			List<QuantityVo> quantityVos = new ArrayList<QuantityVo>();
			List<OrderDetails> quantityMaps = quantityMapDao.findByOrder_Id(order.getId());
			for(OrderDetails i : quantityMaps){
				QuantityVo quantityVo = new QuantityVo();
				quantityVo.setPartNumber(i.getPartNumber());
				quantityVo.setQuantity(i.getQuantity());
				quantityVos.add(quantityVo);
			}
			send.setQuantity(quantityVos);
			sendList.add(send);
		}
		return sendList;
	}

	@Override
	public boolean isAuthenticated(String username, String password){
		User user = userDao.findByUserName(username);
		if(user != null){
			if(password.equals(user.getPassword())){
				user.setStatus(1);
				userDao.save(user);
				return true;
			}
			else{
				user.setStatus(0);
				userDao.save(user);
				return false;
			}
		}
		else 
			return false;
	}
	
	@Override
	public void logoutUser(String username){
		User user = userDao.findByUserName(username);
		if(user != null){
			user.setStatus(0);
			userDao.save(user);
		}
	}

	@Override
	public boolean isLoggedIn(LoginVo loginvo){
		User user = userDao.findByUserName(loginvo.getUserName());
		if(user != null){
			if(user.getStatus()==1)
				return true;
			else
				return false;
		}
		else 
			return false;		
	}
}

