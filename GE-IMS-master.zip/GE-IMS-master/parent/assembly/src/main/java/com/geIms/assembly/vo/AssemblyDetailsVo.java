package com.geIms.assembly.vo;

public class AssemblyDetailsVo {
	private String requestedBy;
	private String assemblyAddress;
	private String assemblyName;
	private long contactNumber;
	public String getRequestedBy() {
		return requestedBy;
	}
	public void setRequestedBy(String requestedBy) {
		this.requestedBy = requestedBy;
	}
	public String getAssemblyAddress() {
		return assemblyAddress;
	}
	public void setAssemblyAddress(String assemblyAddress) {
		this.assemblyAddress = assemblyAddress;
	}
	public String getAssemblyName() {
		return assemblyName;
	}
	public void setAssemblyName(String assemblyName) {
		this.assemblyName = assemblyName;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
}
