package com.geIms.assembly.vo;

import java.util.ArrayList;
import java.util.List;

public class AssemblyVo {
	private String assemblyName;
	private List<PartNumberVo> partNumberList;
	public AssemblyVo(){
		this.partNumberList = new ArrayList<PartNumberVo>();
	}
	public String getAssemblyName() {
		return assemblyName;
	}
	public void setAssemblyName(String assemblyName) {
		this.assemblyName = assemblyName;
	}
	public List<PartNumberVo> getPartNumberList() {
		return partNumberList;
	}
	public void setPartNumberList(List<PartNumberVo> partNumberList) {
		this.partNumberList = partNumberList;
	}
	public void addPartNumber(PartNumberVo partNumberVo){
		this.partNumberList.add(partNumberVo);
	}
}
