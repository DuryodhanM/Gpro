package com.geIms.assembly.vo;

public class ReceiveBookingVo {
	private AssemblyVo assemblyVo;
	private AssemblyDetailsVo assemblyDetailsVo;
	public AssemblyVo getAssemblyVo() {
		return assemblyVo;
	}
	public void setAssemblyVo(AssemblyVo assemblyVo) {
		this.assemblyVo = assemblyVo;
	}
	public AssemblyDetailsVo getAssemblyDetailsVo() {
		return assemblyDetailsVo;
	}
	public void setAssemblyDetailsVo(AssemblyDetailsVo assemblyDetailsVo) {
		this.assemblyDetailsVo = assemblyDetailsVo;
	}
	
}
