package com.geIms.assembly.vo;

import java.util.List;

public class ReceiveGlobalAvail {
	private int partNumber;
	private String itemName;
	private int status;
	private String category;
	private List<String> warehouses;
	private List<Integer> quantity;
	public int getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(int partNumber) {
		this.partNumber = partNumber;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public List<String> getWarehouses() {
		return warehouses;
	}
	public void setWarehouses(List<String> warehouses) {
		this.warehouses = warehouses;
	}
	public List<Integer> getQuantity() {
		return quantity;
	}
	public void setQuantity(List<Integer> quantity) {
		this.quantity = quantity;
	}
}
