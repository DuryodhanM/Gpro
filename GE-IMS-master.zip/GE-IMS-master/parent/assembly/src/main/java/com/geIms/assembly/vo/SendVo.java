package com.geIms.assembly.vo;

import java.util.List;

import io.swagger.annotations.ApiModel;
@ApiModel(description = "Rest Api Response Bean")
public class SendVo {
	private int orderId;
	private int bookingId;
	private String userName;
	private String bookingName;
	private List<QuantityVo> quantity;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getBookingName() {
		return bookingName;
	}
	public void setBookingName(String bookingName) {
		this.bookingName = bookingName;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public List<QuantityVo> getQuantity() {
		return quantity;
	}
	public void setQuantity(List<QuantityVo> quantity) {
		this.quantity = quantity;
	}
}
