package com.geims.globalaging.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.client.RestTemplate;

import com.geims.globalaging.controller.GlobalAgingController;
import com.geims.globalaging.serviceImpl.GlobalAgingServiceImpl;

/**
 * This class includes the bean configuration for the global aging
 * micro-service.
 */

@EnableJpaRepositories("com.geims.globalaging.dao")
@EntityScan("com.geims.globalaging.entity")
@Configuration
@ComponentScan(basePackageClasses = { GlobalAgingServiceImpl.class, GlobalAgingController.class })
public class AppConfig {

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
}
