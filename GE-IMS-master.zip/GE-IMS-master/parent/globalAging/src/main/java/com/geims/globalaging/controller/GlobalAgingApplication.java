package com.geims.globalaging.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

import com.geims.globalaging.config.AppConfig;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * This is the main runnable application which makes use of the
 * configuration class and runs the rest controller.
 * */

@EnableSwagger2
@SpringBootApplication
//@EnableDiscoveryClient
@ComponentScan(  basePackageClasses = { AppConfig.class })
public class GlobalAgingApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(GlobalAgingApplication.class, args);
	}
}
