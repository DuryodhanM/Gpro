package com.geims.globalaging.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.geims.globalaging.service.GlobalAgingService;
import com.geims.globalaging.vo.AgingGraphVo;
import com.geims.globalaging.vo.LoginVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * The Rest controller for the application, this provides the data present in
 * the database as a JSON for respective request mappings
 */

@Api(value = "GlobalAgingController")
@RestController
@CrossOrigin
public class GlobalAgingController {

	@Autowired
	private GlobalAgingService globalAgingService;
	
	/*@ApiOperation(value = "get the current user ")
	@ApiResponses(value = {
			@ApiResponse(code = 404, message = "Items not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/login", consumes = "application/json",method = RequestMethod.POST)
	public void createVo(@RequestBody LoginVo loginVo){
		loginvo = loginVo;
	}*/

	@ApiResponses(value = { @ApiResponse(code = 404, message = "Unable to send graph data"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/graph", method = RequestMethod.POST, produces = "application/json",consumes="application/json")
	public AgingGraphVo getGraphData(@RequestBody LoginVo loginvo) {
		if(globalAgingService.isLoggedIn(loginvo)==true){
			return globalAgingService.getGraph();
		}
		else
			return null;
	}

	@ApiResponses(value = { @ApiResponse(code = 404, message = "Unable to generate Ageing report PDF"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/download", method = RequestMethod.POST,consumes="application/json")
	public void download(HttpServletResponse response,@RequestBody LoginVo loginvo) {
		if(globalAgingService.isLoggedIn(loginvo)==true){
			globalAgingService.downloadPdfaging("Aging report", response);
		}
	}
}
