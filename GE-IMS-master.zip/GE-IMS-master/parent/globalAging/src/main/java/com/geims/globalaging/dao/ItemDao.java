package com.geims.globalaging.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geims.globalaging.entity.GlobalAgingItem;

public interface ItemDao extends JpaRepository<GlobalAgingItem, Long> {
	public List<GlobalAgingItem> findByWarehouseName(String warehouse);
}
