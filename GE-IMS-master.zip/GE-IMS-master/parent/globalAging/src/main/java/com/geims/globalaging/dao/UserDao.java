package com.geims.globalaging.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geims.globalaging.entity.User;

public interface UserDao extends JpaRepository<User, Long> {
	public User findByUserName(String userName);
}
