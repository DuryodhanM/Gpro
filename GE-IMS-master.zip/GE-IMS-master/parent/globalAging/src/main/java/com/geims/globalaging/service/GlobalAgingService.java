package com.geims.globalaging.service;

import javax.servlet.http.HttpServletResponse;

import com.geims.globalaging.vo.LoginVo;
import com.geims.globalaging.vo.AgingGraphVo;

public interface GlobalAgingService {
	public AgingGraphVo getGraph();
	boolean downloadPdfaging(String header, HttpServletResponse response);
	public boolean isLoggedIn(LoginVo loginvo);
}
