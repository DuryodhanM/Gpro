package com.geims.globalaging.serviceImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.geims.globalaging.dao.ItemDao;
import com.geims.globalaging.dao.UserDao;
import com.geims.globalaging.entity.GlobalAgingItem;
import com.geims.globalaging.entity.User;
import com.geims.globalaging.service.GlobalAgingService;
import com.geims.globalaging.vo.AgingGraphVo;
import com.geims.globalaging.vo.LoginVo;
import com.geims.globalaging.vo.QuantityAgeMap;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.Section;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


/**
 * Service Implementation of GlobalAgingService, contains buisiness logic for generating Aging Report
 * @author mythri hegde
 *
 */
@Service
public class GlobalAgingServiceImpl implements GlobalAgingService {
	
	@Autowired
	private ItemDao itemDao;
		
	@Autowired
	private UserDao userDao;

	@Override
	public AgingGraphVo getGraph() {
		AgingGraphVo agingData = new AgingGraphVo();
		QuantityAgeMap below40 = new QuantityAgeMap();
		below40.setAge(39);
		QuantityAgeMap below60 = new QuantityAgeMap();
		below60.setAge(59);
		QuantityAgeMap below90 = new QuantityAgeMap();
		below90.setAge(89);
		QuantityAgeMap above90 = new QuantityAgeMap();
		above90.setAge(100);
		List<GlobalAgingItem> items = itemDao.findAll();
		for(GlobalAgingItem item : items){
			if(calculateAge(item.getMfgDate(),item.getExpDate())<40){
				below40.setQuantity(below40.getQuantity()+item.getQuantity());
			}
			else if(calculateAge(item.getMfgDate(),item.getExpDate())<60){
				below60.setQuantity(below60.getQuantity()+item.getQuantity());
			}
			else if(calculateAge(item.getMfgDate(),item.getExpDate())<90){
				below90.setQuantity(below90.getQuantity()+item.getQuantity());
			}
			else {
				above90.setQuantity(above90.getQuantity()+item.getQuantity());
			}
		}
		List<QuantityAgeMap> quantityList = new ArrayList<QuantityAgeMap>();
		quantityList.add(below40);
		quantityList.add(below60);
		quantityList.add(below90);
		quantityList.add(above90);
		agingData.setGraphData(quantityList);
		return agingData;
	}
	
	/*@Override
	public List<GlobalAgingVo> getGlobalAging(){
		List<GlobalAgingVo> voList = new ArrayList<GlobalAgingVo>();
		List<Item> items = itemDao.findAll();
		voList=getAging(items);
		return voList; 
	}*/
	
	@Override
	public boolean downloadPdfaging(String header, HttpServletResponse response) {
		Document document = new Document(PageSize.A4, 50, 50, 50, 50);
		File file1=null;
		@SuppressWarnings("unused")
		PdfWriter writer=null;
		try{
			try {
				file1 = new File("Aging.pdf");
				file1.createNewFile();
				writer = PdfWriter.getInstance(document, 
						new FileOutputStream(file1));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (DocumentException e) {
				e.printStackTrace();
			}
			document.open();
			Paragraph title1 = new Paragraph("Reports",
					FontFactory.getFont(FontFactory.HELVETICA,
					18, Font.BOLDITALIC, new CMYKColor(0, 255, 255, 17)));
			title1.setAlignment(Element.ALIGN_CENTER);
			Chapter chapter1 = new Chapter(title1, 1);
			chapter1.setNumberDepth(0);
			Section section1 = chapter1.addSection(header);
			section1.setNumberDepth(0);
			
			// Creating table
			PdfPTable table = new PdfPTable(5);
			table.setSpacingBefore(25);
			table.setSpacingAfter(25);
			PdfPCell c1 = new PdfPCell(new Phrase("Age"));
			table.addCell(c1);
			PdfPCell c2 = new PdfPCell(new Phrase("Quantity"));
			table.addCell(c2);			
			PdfPCell c3 = new PdfPCell(new Phrase("ItemName"));
			table.addCell(c3);			
			PdfPCell c4 = new PdfPCell(new Phrase("ManufactureDate"));
			table.addCell(c4);
			PdfPCell c5 = new PdfPCell(new Phrase("ExpiryDate"));
			table.addCell(c5);
			Integer gt_ninety=0,gt_seventy=0,gt_thirty=0,lt_thirty=0;
			List<GlobalAgingItem> items = itemDao.findAll();
			for(GlobalAgingItem item :items){
				if(calculateAge(item.getMfgDate(), item.getExpDate())>90){
					gt_ninety+=item.getQuantity();
				}
				else if(calculateAge(item.getMfgDate(), item.getExpDate())>70){
					gt_seventy+=item.getQuantity();
				}
				else if(calculateAge(item.getMfgDate(), item.getExpDate())>30){
					gt_thirty+=item.getQuantity();
				}
				else{
					lt_thirty+=item.getQuantity();
				}
			}
			for(GlobalAgingItem item : items){
				table.addCell(calculateAge(item.getMfgDate(), item.getExpDate()).toString());
				table.addCell(item.getQuantity().toString());
				table.addCell(item.getItemName());
				table.addCell(item.getMfgDate().toString());
				table.addCell(item.getExpDate().toString());
			}
			section1.add(table);
			Paragraph title2 = new Paragraph("Block-Wise Distribution of Inventory Aging",
			FontFactory.getFont(FontFactory.HELVETICA,
							18, Font.BOLDITALIC, new CMYKColor(0, 255, 255, 17)));
			title2.setAlignment(Element.ALIGN_CENTER);
			Section section2 = chapter1.addSection(title2);
			PdfPTable table1 = new PdfPTable(2);
			table1.setSpacingBefore(100);
			PdfPCell cell = new PdfPCell();
			cell.setFixedHeight(60);
			cell.setBackgroundColor(BaseColor.RED);
			cell.setPaddingRight(20);
			table1.addCell(cell);
			PdfPCell cell2 = new PdfPCell(new Phrase("Quantity:"+gt_ninety.toString()+"(Age>90)", FontFactory.getFont(FontFactory.HELVETICA,
					10, Font.BOLDITALIC, new CMYKColor(0, 255, 255, 17))));
			cell2.setFixedHeight(60);
			cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell2.setBorder(Rectangle.NO_BORDER);
			table1.addCell(cell2);
			PdfPCell cell3 = new PdfPCell();
			cell3.setFixedHeight(60);
			cell3.setBackgroundColor(BaseColor.ORANGE);
			table1.addCell(cell3);
			PdfPCell cell4 = new PdfPCell(new Phrase("Quantity:"+gt_seventy.toString()+"(90>Age>70)", FontFactory.getFont(FontFactory.HELVETICA,10, Font.BOLDITALIC, new CMYKColor(0, 255, 255, 17))));;
			cell4.setFixedHeight(60);
			cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell4.setBorder(Rectangle.NO_BORDER);
			table1.addCell(cell4);
			PdfPCell cell5 = new PdfPCell();
			cell5.setBackgroundColor(BaseColor.YELLOW);
			cell5.setFixedHeight(60);
			table1.addCell(cell5);
			PdfPCell cell6 = new PdfPCell(
					new Phrase("Quantity:"+gt_thirty.toString()+"(70>Age>30)", FontFactory.getFont(FontFactory.HELVETICA,10, Font.BOLDITALIC, new CMYKColor(0, 255, 255, 17))));;
			cell6.setFixedHeight(60);
			cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell6.setBorder(Rectangle.NO_BORDER);
			table1.addCell(cell6);
			PdfPCell cell7 = new PdfPCell();
			cell7.setBackgroundColor(BaseColor.GREEN);
			cell7.setFixedHeight(60);
			table1.addCell(cell7);
			PdfPCell cell8 = new PdfPCell(
					new Phrase("Quantity:"+lt_thirty.toString()+"(30>Age)", FontFactory.getFont(FontFactory.HELVETICA,10, Font.BOLDITALIC, new CMYKColor(0, 255, 255, 17))));;
			cell8.setFixedHeight(60);
			cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
			cell8.setBorder(Rectangle.NO_BORDER);
			table1.addCell(cell8);
			section2.add(table1);
			try {
				document.add(chapter1);
			} catch (DocumentException e) {
				e.printStackTrace();
			}
			document.close();
			toReadandWriteFile(file1,response);
			return true;
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
		return false;
	}
	
	@Override
	public boolean isLoggedIn(LoginVo loginvo){
		User user = userDao.findByUserName(loginvo.getUserName());
		if(user.getStatus()==1)
			return true;
		else
			return false;
		
	}
	
	private void toReadandWriteFile(File file1, HttpServletResponse response) {
		OutputStream outStream = null;
		response.setHeader("Content-Disposition","attachment; filename="+"AgeingReport.pdf");
		try {
			outStream = response.getOutputStream();
		} catch (IOException e) {
			e.printStackTrace();
		}
		FileInputStream   fis=null;
		try {
			fis = new FileInputStream(file1);
			int content;
			while ((content = fis.read()) != -1) {
				outStream.write((char)content);
			}
			outStream.flush();
		}
		catch(FileNotFoundException ex) {
			System.out.println("Unable to open file '" + file1 + "'");                
		}
		catch(IOException ex) {
			System.out.println(	"Error reading file '" + file1 + "'");
		}
		finally {
			try {
				if (fis != null)
					fis.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
	}
	
	private Long calculateAge(Date mfgDate, Date expDate) {
		Date curDate = new Date();
		double numerator = getDateDiff(curDate, mfgDate, TimeUnit.DAYS);
		double denominator = getDateDiff(expDate, mfgDate, TimeUnit.DAYS);
		double age=(numerator/denominator)*100.00;
		return Math.round(age);
	}

	private long getDateDiff(Date date1, Date date2, TimeUnit timeUnit) {
		long diffInSeconds = date1.getTime() - date2.getTime();
		long days = timeUnit.convert(diffInSeconds,TimeUnit.DAYS);
		return days;
	}

	
}
