package com.geims.globalaging.vo;

import java.util.List;

public class AgingGraphVo {
	private List<QuantityAgeMap> graphData;

	public List<QuantityAgeMap> getGraphData() {
		return graphData;
	}

	public void setGraphData(List<QuantityAgeMap> graphData) {
		this.graphData = graphData;
	}
}
