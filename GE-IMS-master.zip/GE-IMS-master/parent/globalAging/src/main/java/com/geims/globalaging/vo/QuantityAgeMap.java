package com.geims.globalaging.vo;

public class QuantityAgeMap {
	private Integer age;
	private Integer quantity;
	public QuantityAgeMap() {
		// TODO Auto-generated constructor stub
		age = 0;
		quantity = 0;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	
}
