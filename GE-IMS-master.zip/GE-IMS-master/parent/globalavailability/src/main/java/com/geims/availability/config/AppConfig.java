//package com.geims.globalavailability.config;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.autoconfigure.domain.EntityScan;
//import org.springframework.boot.autoconfigure.web.ErrorAttributes;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//
//import com.geims.globalavailability.controller.GlobalAvailabilityController;
//import com.geims.globalavailability.service.GlobalAvailabilityService;
//
//@EnableJpaRepositories("com.geims.globalavailability.dao")
//@EntityScan("com.geims.globalavailability.entity")
//@Configuration
//// @ComponentScan(basePackageClasses = { GlobalAvailabilityService.class,
//// GlobalAvailabilityController.class })
//@ComponentScan(basePackages = { "com.geims.globalavailability.service" })
//public class AppConfig {
//
////	@Autowired
////	private ErrorAttributes errorAttributes;
////
////	@Bean
////	public AppErrorController appErrorController() {
////		return new AppErrorController(errorAttributes);
////	}
//}

package com.geims.availability.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.web.ErrorAttributes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.client.RestTemplate;

import com.geims.availability.controller.AppErrorController;

@EnableJpaRepositories("com.geims.availability.dao")
@EntityScan("com.geims.availability.entity")
@Configuration
/*@ComponentScan(basePackageClasses = { GlobalAvailabilityServiceImpl.class, GlobalAvailabilityController.class })*/
@ComponentScan(basePackages = { "com.geims.availability.service","com.geims.availability.serviceImpl","com.geims.availability.controller" })
public class AppConfig {
	@Autowired
	private ErrorAttributes errorAttributes;

	@Bean
	public AppErrorController appErrorController() {
		return new AppErrorController(errorAttributes);
	}

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

}