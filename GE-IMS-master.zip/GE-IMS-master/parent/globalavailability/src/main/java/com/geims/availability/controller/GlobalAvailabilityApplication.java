package com.geims.availability.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

import com.geims.availability.config.AppConfig;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * 
 * @author Vishal Verma
 * @author $LastChangedBy: Vishal Verma
 * @version $Revision:001 $, $Date: 12/10/2016
 */

@EnableSwagger2
@SpringBootApplication
//@EnableDiscoveryClient
@ComponentScan(basePackageClasses = { AppConfig.class })
public class GlobalAvailabilityApplication {
	public static void main(String[] args) {
		SpringApplication.run(GlobalAvailabilityApplication.class, args);
	}
}
