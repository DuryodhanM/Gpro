package com.geims.availability.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.geims.availability.service.GlobalAvailabilityService;
import com.geims.availability.vo.FilterVo;
import com.geims.availability.vo.GlobalItemVo;
import com.geims.availability.vo.LocalItemVo;
import com.geims.availability.vo.LoginVo;
import com.geims.availability.vo.SearchVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Inventory Availability Controller
 * @author Vishal Verma
 * @author $LastChangedBy: Vivek Bengre
 * @version $Revision:001 $, $Date: 12/10/2016
 * @version $Revision:002 $,$Date: 20/10/2016
 */
@Api(value = "GlobalAvailabilityController", description = " Get item availability across all warehouses")
@RestController
@CrossOrigin
public class GlobalAvailabilityController {
	
	@Autowired
	private GlobalAvailabilityService globalAvailabilityService;
		
	/*@ApiOperation(value = "get the current user ")
	@ApiResponses(value = {
			@ApiResponse(code = 404, message = "Items not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/login", consumes = "application/json",method = RequestMethod.POST)
	public void createVo(@RequestBody LoginVo loginVo){
		loginvo = loginVo;
	}*/
	
	@ApiOperation(value = "get all items across all warehouses ", notes = "Provides item related data across all wareouses")
	@ApiResponses(value = {
			@ApiResponse(code = 404, message = "Items not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/global",produces = "application/json",method = RequestMethod.POST,consumes = "application/json")
	public List<GlobalItemVo> getAllItems(@RequestBody LoginVo loginvo){
		if(globalAvailabilityService.isLoggedIn(loginvo)==true){			
			return globalAvailabilityService.getGlobalAvailabilityData();
		}
		else{
			return null;
		}
	}
	
	@ApiOperation(value = "get all items according to a particular invetory warehouse ", notes = "Return all the items in a warehouse for a given warehouse id")
	@ApiResponses(value = {
			@ApiResponse(code = 400, message = "Invalid warehouse supplied"),
			@ApiResponse(code = 404, message = "Items not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value="/local/{warehouseId}",produces = "application/json",method = RequestMethod.POST,consumes = "application/json")
	public List<LocalItemVo> getLocalAging(
			@ApiParam(name="warehouseId") @PathVariable("warehouseId") int warehouseId,@RequestBody LoginVo loginvo){
		if(globalAvailabilityService.isLoggedIn(loginvo)==true){
			return globalAvailabilityService.getLocalAvailabilityData(warehouseId);
		}
		else
			return null;
	}
	@ApiOperation(value = "Post Search data to search service", notes = "Post Search data to search service")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Search data cannot be posted"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "get/all/{userName}", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public @ResponseBody List<SearchVo> getSearchResults(@RequestBody FilterVo filterVo,@PathVariable("userName") String userName) {
			LoginVo loginVo = new LoginVo();
			loginVo.setUserName(userName);
			if(globalAvailabilityService.isLoggedIn(loginVo)){
				List<GlobalItemVo> globalItemVo = globalAvailabilityService.getGlobalAvailabilityData();
				List<SearchVo> searchResults = globalAvailabilityService.send(filterVo, globalItemVo);
				return searchResults;
			}
			else{
				return null;
			}
		
	}
}