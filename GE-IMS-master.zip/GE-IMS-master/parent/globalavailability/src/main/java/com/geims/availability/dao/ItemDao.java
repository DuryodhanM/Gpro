package com.geims.availability.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geims.availability.entity.GlobalAvailabilityItem;

public interface ItemDao extends JpaRepository<GlobalAvailabilityItem, Long>{
	public List<GlobalAvailabilityItem> findByWarehouseId(int warehouseId);
	public List<GlobalAvailabilityItem> findByPartNumber(int partNumber);
}
