package com.geims.availability.service;

import java.util.List;

import org.springframework.stereotype.Service;
import com.geims.availability.vo.FilterVo;
import com.geims.availability.vo.GlobalItemVo;
import com.geims.availability.vo.LocalItemVo;
import com.geims.availability.vo.LoginVo;
import com.geims.availability.vo.SearchVo;

/**
 * Service interface for inventory availability
 * @author Vishal Verma
 * @author $LastChangedBy: Vivek Bengre
 * @version $Revision:001 $, $Date: 20/10/2016
 */
@Service
public interface GlobalAvailabilityService {
	public List<GlobalItemVo> getGlobalAvailabilityData();
	public List<LocalItemVo> getLocalAvailabilityData(int warehouseId);
	public GlobalItemVo getPartWiseDetails(int partNumber);
	public boolean isLoggedIn(LoginVo loginvo);
	public List<SearchVo> send(FilterVo filterVo, List<GlobalItemVo> globalItemVo);
}