package com.geims.availability.serviceImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.geims.availability.dao.ItemDao;
import com.geims.availability.dao.UserDao;
import com.geims.availability.entity.GlobalAvailabilityItem;
import com.geims.availability.entity.User;
import com.geims.availability.service.GlobalAvailabilityService;
import com.geims.availability.vo.FilterVo;
import com.geims.availability.vo.GlobalItemVo;
import com.geims.availability.vo.LocalItemVo;
import com.geims.availability.vo.LoginVo;
import com.geims.availability.vo.SearchVo;

/**
 * Service Implementation for Global Availability Service interface
 * @author Vishal Verma
 * @author $LastChangedBy: Vivek Bengre
 * @version $Revision:001 $, $Date: 12/10/2016
 * @version $Revision:002 $,$Date:20/10/2016
 */

@Service
public class GlobalAvailabilityServiceImpl implements GlobalAvailabilityService {

	@Autowired
	private ItemDao itemDao;
		
	@Autowired
	private UserDao userDao;
	
	@Override
	/**
	 * Gets the list of all the items present according to the warehouse
	 * each item is listen along with a list of warehouses its present with 
	 * item quantity and total value
	 * 
	 * */
	public List<GlobalItemVo> getGlobalAvailabilityData() {
		// TODO Auto-generated method stub
		List<GlobalAvailabilityItem> itemList = itemDao.findAll();
		List<GlobalItemVo> itemVoList = new ArrayList<GlobalItemVo>();
		HashSet<String> itemName = new HashSet<String>();
		//stores the list of all the unique items
		for(GlobalAvailabilityItem item : itemList){
			itemName.add(item.getItemName());
		}
		// uses the list of unique items to calculate warehouse wise quantity
		// and warehouse wise value
		for(String item: itemName){
			GlobalItemVo itemVo = new GlobalItemVo();
			itemVo.setItemName(item);
			for(GlobalAvailabilityItem i : itemList){
				if(item.equals(i.getItemName())){
					itemVo.setCategory(i.getCategory());
					itemVo.setPartNumber(i.getPartNumber());
					itemVo.setStatus(i.getStatus());
					int index  = itemVo.getWarehouses().indexOf(i.getWarehouseName());
					// if warehouse already is entered in the list add the quantity and value
					if(index >= 0 && i.getStatus()!=0){
						itemVo.addQuantity(index, itemVo.getQuantity().get(index)+i.getQuantity());
						itemVo.addValue(index, itemVo.getValue().get(index)+i.getCost());
					}
					// if a warehouse isn't present add it as a separate entry in the warehouse quantity and cost list 
					else{
						if(i.getStatus()!=0)
							itemVo.addRecord(i.getQuantity(), i.getWarehouseName(),i.getCost());
					}
				}
			}
			itemVoList.add(itemVo);
		}
		return itemVoList;
	}

	@Override
	/**Gets warehouse wise information, gets the list of items present in the warehouse
	 * along with their quantity and unit cost
	 * */
	public List<LocalItemVo> getLocalAvailabilityData(int warehouseId) {
		// TODO Auto-generated method stub
		List<GlobalAvailabilityItem> itemList= itemDao.findByWarehouseId(warehouseId);
		List<LocalItemVo> itemVoList = new ArrayList<LocalItemVo>();
		for(GlobalAvailabilityItem item :itemList){
			LocalItemVo temp = new LocalItemVo();
			temp.setCategory(item.getCategory());
			temp.setItemName(item.getItemName());
			temp.setPartNumber(item.getPartNumber());
			temp.setQuantity(item.getQuantity());
			temp.setWarehouseName(item.getWarehouseName());
			temp.setCost(item.getCost());
			itemVoList.add(temp);
		}
		return itemVoList;
	}

	@Override
	public GlobalItemVo getPartWiseDetails(int partNumber) {
		// TODO Auto-generated method stub
		/**
		 * find the details pertaining to a particular item based on part number
		 * sets itemName category and partNumber as they are common to all 
		 * the items,
		 * It checks if the item is present in the warehouse and if so it adds the 
		 * quantity and cost/value of each of these individual items, if it isn't present 
		 * it adds the new value in the respective location in the list
		 * */
		List<GlobalAvailabilityItem> items = itemDao.findByPartNumber(partNumber);
		GlobalItemVo itemVo =new GlobalItemVo();
		if(items != null){
			itemVo.setItemName(items.get(0).getItemName());
			itemVo.setCategory(items.get(0).getCategory());
			itemVo.setPartNumber(items.get(0).getPartNumber());
		}
		for(GlobalAvailabilityItem i : items){
			if(i.getStatus()>0){
				if(itemVo.getWarehouses() != null){
					int index  = itemVo.getWarehouses().indexOf(i.getWarehouseName());
					if(index >= 0){
						itemVo.addQuantity(index, itemVo.getQuantity().get(index)+i.getQuantity());
						itemVo.addValue(index,itemVo.getValue().get(index)+i.getCost());
					}
					else{
						itemVo.addRecord(i.getQuantity(), i.getWarehouseName(),i.getCost());
					}
				}
			}
		}
		return itemVo;
	}
	
	@Override
	public boolean isLoggedIn(LoginVo loginvo){
		User user = userDao.findByUserName(loginvo.getUserName());
		if(user.getStatus()==1)
			return true;
		else
			return false;		
	}
	
	@Override
	/**
	 * Gets the availability based on the filters provided and retains only 
	 * those values which are present in the filters received fromt he front end
	 * */
	public List<SearchVo> send(FilterVo filterVo, List<GlobalItemVo> globalItemVo) {
		List<SearchVo> warehouseobjList = new ArrayList<SearchVo>();
		List<SearchVo> itemobjList = new ArrayList<SearchVo>();
		List<SearchVo> categoryobjList = new ArrayList<SearchVo>();
		List<SearchVo> partobjList = new ArrayList<SearchVo>();
		List<SearchVo> allList = new ArrayList<SearchVo>();
		
		if(filterVo.getWarehouse()!=null&&filterVo.getWarehouse().length()!=0){
			for (GlobalItemVo item : globalItemVo) {
				List<String> whNames = item.getWarehouses();
				for (String whName : whNames) {
					if (whName.equals(filterVo.getWarehouse())) {
						SearchVo searchobj = new SearchVo();
						searchobj.setCategory(item.getCategory());
						searchobj.setItemName(item.getItemName());
						searchobj.setPartNumber(item.getPartNumber());
						searchobj.setWarehouse(whName);
						int index = whNames.indexOf(whName);
						searchobj.setQuantity(item.getQuantity().get(index));
						warehouseobjList.add(searchobj);
					}
				}
			}
		}
		if((filterVo.getItemName()!=null)&&(filterVo.getItemName().length()!=0)){
			for (GlobalItemVo item : globalItemVo) {
				String itemName=item.getItemName();
				if(itemName.equals(filterVo.getItemName())){
					List<String> whNames = item.getWarehouses();
					for(String whName : whNames){
						SearchVo searchobj=new SearchVo();
						searchobj.setItemName(item.getItemName());
						searchobj.setCategory(item.getCategory());
						searchobj.setPartNumber(item.getPartNumber());
						searchobj.setWarehouse(whName);
						int index = whNames.indexOf(whName);
						searchobj.setQuantity(item.getQuantity().get(index));
						itemobjList.add(searchobj);
					}
					
					
				}
			}
		}
		if((filterVo.getCategory()!=null)&&(filterVo.getCategory().length()!=0)){
			for (GlobalItemVo item : globalItemVo) {
				String category=item.getCategory();
				if(category.equals(filterVo.getCategory())){
					List<String> whNames = item.getWarehouses();
					for(String whName : whNames){
						SearchVo searchobj=new SearchVo();
						searchobj.setItemName(item.getItemName());
						searchobj.setCategory(item.getCategory());
						searchobj.setPartNumber(item.getPartNumber());
						searchobj.setWarehouse(whName);
						int index = whNames.indexOf(whName);
						searchobj.setQuantity(item.getQuantity().get(index));
						categoryobjList.add(searchobj);
					}
					
					
				}
			}
		}
		if(filterVo.getPartNumber()!=null){
			for (GlobalItemVo item : globalItemVo) {
				int partNumber=item.getPartNumber();
				if(partNumber==filterVo.getPartNumber()){
					List<String> whNames = item.getWarehouses();
					for(String whName : whNames){
						SearchVo searchobj=new SearchVo();
						searchobj.setItemName(item.getItemName());
						searchobj.setCategory(item.getCategory());
						searchobj.setPartNumber(item.getPartNumber());
						searchobj.setWarehouse(whName);
						int index = whNames.indexOf(whName);
						searchobj.setQuantity(item.getQuantity().get(index));
						partobjList.add(searchobj);
					}
					
					
				}
			}
		}
		for (GlobalItemVo item : globalItemVo) {
			List<String> whNames = item.getWarehouses();
			for(String whName : whNames){
				SearchVo searchobj=new SearchVo();
				searchobj.setItemName(item.getItemName());
				searchobj.setCategory(item.getCategory());
				searchobj.setPartNumber(item.getPartNumber());
				searchobj.setWarehouse(whName);
				int index = whNames.indexOf(whName);
				searchobj.setQuantity(item.getQuantity().get(index));
				allList.add(searchobj);
			}
		}
		if(filterVo.getWarehouse()==null&&filterVo.getItemName()==null&&filterVo.getPartNumber()==null&&filterVo.getCategory()==null)
			return allList;			
				
		if(filterVo.getWarehouse()!=null&&filterVo.getWarehouse().length()!=0){
			allList.retainAll(warehouseobjList);
		}
		if((filterVo.getItemName()!=null)&&(filterVo.getItemName().length()!=0)){
			allList.retainAll(itemobjList);
		}
		if((filterVo.getCategory()!=null)&&(filterVo.getCategory().length()!=0)){
			allList.retainAll(categoryobjList);
		}
		if(filterVo.getPartNumber()!=null){
			allList.retainAll(partobjList);
		}
		return allList;

	}

}
