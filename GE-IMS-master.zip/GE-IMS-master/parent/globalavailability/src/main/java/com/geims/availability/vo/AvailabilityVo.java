package com.geims.availability.vo;

/**
 * 
 * @author Vishal Verma
 * @author $LastChangedBy: Vishal Verma
 */
public class AvailabilityVo {

	private Integer warehouseId;
	private Integer qty;

	public Integer getWarehouseId() {
		return warehouseId;
	}

	public void setWarehouseId(Integer warehouseId) {
		this.warehouseId = warehouseId;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

}
