package com.geims.availability.vo;

import java.util.ArrayList;
import java.util.List;

public class GlobalItemVo {
	private int partNumber;
	private String itemName;
	private int status;
	private String category;
	private List<String> warehouses;
	private List<Integer> quantity;
	private List<Integer> value;

	public GlobalItemVo() {
		this.warehouses = new ArrayList<String>();
		this.quantity = new ArrayList<Integer>();
		this.value = new ArrayList<Integer>();
	}

	public int getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(int partNumber) {
		this.partNumber = partNumber;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public List<String> getWarehouses() {
		return warehouses;
	}

	public void setWarehouses(List<String> warehouses) {
		this.warehouses = warehouses;
	}

	public List<Integer> getQuantity() {
		return quantity;
	}

	public void setQuantity(List<Integer> quantity) {
		this.quantity = quantity;
	}

	public void addWarehouse(int index, String warehouse) {
		this.warehouses.add(index, warehouse);
	}

	public void addQuantity(int index, int quantity) {
		this.quantity.add(index, quantity);
	}
	
	public void addValue(int index,int value){
		this.value.add(index, value);
	}

	public void addRecord(int quantity, String warehouse, int cost) {
		this.quantity.add(quantity);
		this.warehouses.add(warehouse);
		this.value.add(cost);
	}

	public List<Integer> getValue() {
		return value;
	}

	public void setValue(List<Integer> value) {
		this.value = value;
	}
}
