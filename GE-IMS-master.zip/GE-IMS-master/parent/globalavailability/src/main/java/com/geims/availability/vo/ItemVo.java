package com.geims.availability.vo;

import java.util.List;

import io.swagger.annotations.ApiModel;

/**
 * 
 * @author Vishal Verma
 * @author $LastChangedBy: Vishal Verma
 * @version $Revision:001 $, $Date: 12/10/2016
 */

@ApiModel(description = "Rest Api Response Bean")
public class ItemVo {

	private Integer partNumber;
	private String itemName;
	private int status;
	private String category;
	private List<AvailabilityVo> availabilityList;
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Integer getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(Integer partNumber) {
		this.partNumber = partNumber;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public List<AvailabilityVo> getAvailabilityList() {
		return availabilityList;
	}

	public void setAvailabilityList(List<AvailabilityVo> availabilityList) {
		this.availabilityList = availabilityList;
	}

}
