package com.geims.localaging.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.geims.localaging.service.LocalAgingService;
import com.geims.localaging.vo.ItemVO;
import com.geims.localaging.vo.LoginVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value = "LocalAgingController")
@RestController
@CrossOrigin
public class Controller {

	@Autowired
	private LocalAgingService localAgingService;

	@ApiOperation(value = "get item aging local to a warehouse by warhouse and item", notes = "Aging is local to the warehouse time")
	@ApiResponses(value = { @ApiResponse(code = 400, message = "Invalid warehouse id supplied"),
			@ApiResponse(code = 404, message = "Items not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/{warehouseId}/{partNumber}", method = RequestMethod.POST, produces = "application/json",consumes = "application/json")
	public ItemVO getLocalAging(@PathVariable("warehouseId") int warehouseId,
			@PathVariable("partNumber") int partNumber,@RequestBody LoginVo loginvo) {
		if (localAgingService.isLoggedIn(loginvo) == true) {
			return localAgingService.getLocalAging(warehouseId, partNumber);
		} else
			return null;

	}

	/*@ApiOperation(value = "get the current user ")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Items not found"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/login", consumes = "application/json", method = RequestMethod.POST)
	public void createVo(@RequestBody LoginVo loginVo) {
		loginvo = loginVo;
	}*/

}
