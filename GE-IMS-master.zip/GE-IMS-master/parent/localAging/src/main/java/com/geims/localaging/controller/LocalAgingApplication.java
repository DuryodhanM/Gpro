package com.geims.localaging.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

import com.geims.localaging.config.AppConfig;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@SpringBootApplication
//@EnableDiscoveryClient
@ComponentScan(basePackageClasses = {AppConfig.class})
public class LocalAgingApplication {
	public static void main(String[] args){
		// TODO Auto-generated method stub
		SpringApplication.run(LocalAgingApplication.class, args);
	}
}
