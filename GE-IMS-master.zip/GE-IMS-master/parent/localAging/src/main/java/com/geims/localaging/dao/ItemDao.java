package com.geims.localaging.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geims.localaging.entity.LocalAgingItem;

public interface ItemDao extends JpaRepository<LocalAgingItem, Long> {
	public List<LocalAgingItem> findByWarehouseId(int warehouseId);
	public List<LocalAgingItem> findByPartNumber(int partNumber);
	public List<LocalAgingItem> findByWarehouseIdAndPartNumber(int warehouseId,int partNumber);
}
