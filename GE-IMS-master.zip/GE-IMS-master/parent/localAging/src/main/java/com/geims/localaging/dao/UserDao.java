package com.geims.localaging.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geims.localaging.entity.User;

public interface UserDao extends JpaRepository<User, Long> {
	public User findByUserName(String userName);
}
