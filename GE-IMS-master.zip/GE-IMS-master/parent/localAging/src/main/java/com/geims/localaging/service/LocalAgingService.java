package com.geims.localaging.service;

import com.geims.localaging.vo.ItemVO;
import com.geims.localaging.vo.LoginVo;

public interface LocalAgingService {
	public ItemVO getLocalAging(int warehouseId,int partNumber);
	public boolean isLoggedIn(LoginVo loginvo);
}
