package com.geims.localaging.serviceimpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.geims.localaging.dao.ItemDao;
import com.geims.localaging.dao.UserDao;
import com.geims.localaging.entity.LocalAgingItem;
import com.geims.localaging.entity.User;
import com.geims.localaging.service.LocalAgingService;
import com.geims.localaging.vo.ItemVO;
import com.geims.localaging.vo.LoginVo;

@Service
public class LocalAgingServiceImplementation implements LocalAgingService{

	@Autowired
	private ItemDao itemDao;
		
	@Autowired
	private UserDao userDao;
	
	@Override
	public ItemVO getLocalAging(int warehouseId, int partNumber) {
		// TODO Auto-generated method stub
		List<LocalAgingItem> itemList = itemDao.findByWarehouseIdAndPartNumber(warehouseId, partNumber);
		ItemVO itemVo = new ItemVO();
		Date date = new Date();
		List<Long> age = new ArrayList<Long>();
		List<Long> qty = new ArrayList<Long>();
		if(itemList != null){
			itemVo.setItemName(itemList.get(0).getItemName());
			itemVo.setItemId(partNumber);
			for(LocalAgingItem item:itemList){
				int index = age.indexOf((date.getTime()-item.getInTime().getTime())/86300000);
				if(index >= 0){
					itemVo.addQtyToPosition(index, item.getQuantity()+qty.get(index));
				}
				else{
					itemVo.addRecord((long) item.getQuantity(), (date.getTime()-item.getInTime().getTime())/86300000);
				}
			}
		}
		return itemVo;
	}
	
	@Override
	public boolean isLoggedIn(LoginVo loginvo){
		User user = userDao.findByUserName(loginvo.getUserName());
		if(user.getStatus()==1)
			return true;
		else
			return false;
		
	}
}
