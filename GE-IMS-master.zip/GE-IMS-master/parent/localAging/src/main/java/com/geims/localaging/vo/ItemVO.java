package com.geims.localaging.vo;

import java.util.ArrayList;
import java.util.List;

public class ItemVO {
	
	private int itemId;
	private String itemName;
	private List<Long> age;
	private List<Long> Quantity;
	
	public ItemVO(){
		this.age = new ArrayList<Long>();
		this.Quantity = new ArrayList<Long>();
	}
	
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public List<Long> getAge() {
		return age;
	}
	public void setAge(List<Long> age) {
		this.age = age;
	}
	public List<Long> getQuantity() {
		return Quantity;
	}
	public void setQuantity(List<Long> quantity) {
		Quantity = quantity;
	}
	
	public void addAgeToPosition(int index,Long age){
		this.age.add(index,age);
	}
	
	public void addQtyToPosition(int index,Long qty){
		this.Quantity.add(index,qty);
	}
	
	public void addRecord(Long qty,Long age){
		this.Quantity.add(qty);
		this.age.add(age);
	}
	
}
