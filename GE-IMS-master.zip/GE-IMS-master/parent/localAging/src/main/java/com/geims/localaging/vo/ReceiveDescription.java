package com.geims.localaging.vo;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import  com.geims.localaging.config.CustomDateSerializer;

public class ReceiveDescription {
	
	private String rfid;
	private Date inTime;
	private int itemId;
	private int categoryId;
	private int warehouseId;
	private int status;
	
	public String getRfid() {
		return rfid;
	}
	public void setRfid(String rfid) {
		this.rfid = rfid;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getInTime() {
		return inTime;
	}
	public void setInTime(Date inTime) {
		this.inTime = inTime;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getWarehouseId() {
		return warehouseId;
	}
	public void setWarehouseId(int warehouseId) {
		this.warehouseId = warehouseId;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
}
