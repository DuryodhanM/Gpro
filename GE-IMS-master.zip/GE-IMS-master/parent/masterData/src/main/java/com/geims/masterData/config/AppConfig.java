package com.geims.masterData.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.geims.masterData.controller.Controller;
import com.geims.masterData.serviceImpl.MasterDataServiceImpl;

@EntityScan({"com.geims.masterData.entity"})
@EnableJpaRepositories({"com.geims.masterData.dao"})
@Configuration
@ComponentScan(basePackageClasses = {MasterDataServiceImpl.class,Controller.class})
public class AppConfig {
	
}
