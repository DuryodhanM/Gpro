package com.geims.masterData.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.geims.masterData.vo.LoginVo;
import com.geims.masterData.vo.MasterLoginVo;
import com.geims.masterData.dao.UserDao;
import com.geims.masterData.entity.Category;
import com.geims.masterData.entity.User;
import com.geims.masterData.entity.Warehouse;
import com.geims.masterData.service.MasterDataService;
import com.geims.masterData.vo.AssemblyVo;
import com.geims.masterData.vo.ReceiveItem;
import com.geims.masterData.vo.ReceiveSearchParameters;
import com.geims.masterData.vo.ReceiveVo;
import com.geims.masterData.vo.SendSearchResult;
import com.geims.masterData.vo.SendVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Api(value="MasterDataController",description="Master Data controller")
@RestController
@CrossOrigin
@RequestMapping(value = "/")
public class Controller {
	
	@Autowired
	MasterDataService masterDataService;
	
	@Autowired
	UserDao userDao;
	
	@ApiOperation(value = "Save item", notes="Updates inventory item ")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Items cannot be saved"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/put/item",consumes = "application/json",method = RequestMethod.POST)
	public void updateItem(@RequestBody ReceiveItem item){
		masterDataService.updateItem(item);
	}
	
	@ApiOperation(value = "Save warehouse details", notes="Updates warehouse related data")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "warehouse data cannot be saved"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/put/warehouse",consumes = "application/json", method = RequestMethod.POST)
	public void updateWarehouse(@RequestBody Warehouse warehouse){
		masterDataService.updateWarehouse(warehouse);
	}
	
	
	@ApiOperation(value = "Save rfid tag details", notes="Save rfid related data")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Tag data cannot be saved"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/put/tag",consumes = "application/json",method = RequestMethod.POST)
	public void updateTag(@RequestBody ReceiveVo receiveVo){
		masterDataService.updateTagDetails(receiveVo);
	}
	
	@ApiOperation(value = "Get complete inventory record", notes="Gets one complete inventory record")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Inventory details cannot be fetched"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/get",consumes = "application/json",method = RequestMethod.POST)
	public @ResponseBody SendVo retrieveAndUpdate(@RequestBody ReceiveVo receiveVo){
		return masterDataService.updateAndSend(receiveVo);
	}

	@ApiOperation(value = "Save Category data", notes="Save/Update category data ")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Items cannot be saved"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "put/category",method = RequestMethod.POST,consumes = "application/json")
	public void updateCategory(@RequestBody Category category){
		masterDataService.updateCategory(category);
	}
	
	@ApiOperation(value = "Get search data for search service", notes="Custom search for providing search facility")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Search cannot be made"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "get/search",method = RequestMethod.POST,consumes = "application/json",produces = "application/json")
	public @ResponseBody SendSearchResult getDetails( @RequestBody ReceiveSearchParameters param){
		return masterDataService.send(param);
		
	}
	
	@ApiOperation(value = "Update part number/item details", notes="Manage booked item in the inventory")
	@ApiResponses(value = { @ApiResponse(code = 404, message = "Unable to update item"),
			@ApiResponse(code = 200, message = "Successful response send"),
			@ApiResponse(code = 500, message = "Server error") })
	@RequestMapping(value = "/get/item",consumes = "application/json",produces = "application/json",method = RequestMethod.POST)
	public @ResponseBody List<Double> updateInventory(@RequestBody AssemblyVo assemblyVo){		
		return masterDataService.updateInventoryItem(assemblyVo);		
	}

	@RequestMapping(value ="/login", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
	public @ResponseBody MasterLoginVo login(@RequestBody LoginVo loginVo){
		MasterLoginVo masterLoginVo = new MasterLoginVo();
		String username = loginVo.getUserName();
		String password = loginVo.getPassword();
		if(masterDataService.isAuthenticated(username,password)==true){
			masterLoginVo.setAuthenticated(true);
		}
		else{
			masterLoginVo.setAuthenticated(false);
		}
		return masterLoginVo;
	}
	
	@RequestMapping(value="/logout",method = RequestMethod.POST, consumes = "application/json")
	public void logout(@RequestBody LoginVo loginVo){
		String username = loginVo.getUserName();
		masterDataService.logoutUser(username);
	}
	@RequestMapping(value="/user",method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public User user(@RequestBody LoginVo loginVo){
		User user = userDao.findByUserName(loginVo.getUserName());
		return user;
	}

}

