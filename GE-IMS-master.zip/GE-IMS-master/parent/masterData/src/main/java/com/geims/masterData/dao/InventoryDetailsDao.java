package com.geims.masterData.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geims.masterData.entity.InventoryDetails;

public interface InventoryDetailsDao extends JpaRepository<InventoryDetails, Long> {
	public List<InventoryDetails> findByWarehouse_Id(int id);
	public List<InventoryDetails> findByCost(Double cost);
	public List<InventoryDetails> findByTagDetails_Item_Id(int partNumber);
	public List<InventoryDetails> findByTagDetails_Item_ItemName(String itemName);
	public List<InventoryDetails> findByTagDetails_Item_Category_Category(String category);	
}
