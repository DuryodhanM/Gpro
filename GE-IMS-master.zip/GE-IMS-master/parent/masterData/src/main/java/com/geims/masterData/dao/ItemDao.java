package com.geims.masterData.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geims.masterData.entity.Item;

public interface ItemDao extends JpaRepository<Item, Long> {
	public Item findById(int id);
	public Item findByItemName(String itemName);
}
