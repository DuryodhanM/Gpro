package com.geims.masterData.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geims.masterData.entity.TagDetails;

public interface TagDetailsDao extends JpaRepository<TagDetails, Long> {
	public TagDetails findById(int id);
	public TagDetails findByRfid(String rfid);
}
