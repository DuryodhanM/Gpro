package com.geims.masterData.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geims.masterData.entity.User;

public interface UserDao extends JpaRepository<User, Long>{
	public User findById(int id);
	public User findByUserName(String userName);
}
