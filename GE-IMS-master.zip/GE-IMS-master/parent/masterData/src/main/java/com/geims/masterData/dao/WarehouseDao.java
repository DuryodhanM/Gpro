package com.geims.masterData.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.geims.masterData.entity.Warehouse;

public interface WarehouseDao extends JpaRepository<Warehouse, Long>{
	public Warehouse findById(int id);
}
