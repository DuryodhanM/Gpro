package com.geims.masterData.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.geims.masterData.config.CustomDateSerializer;

@Entity
@Table(name = "inventoryDetails")
public class InventoryDetails {
	private int id;
	private Warehouse warehouse;
	private Date inTime;
	private Date outTime;
	private int status;
	private TagDetails tagDetails;
	private double cost;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@JoinColumn(name = "warehouseId")
	@ManyToOne(fetch=FetchType.LAZY,cascade = CascadeType.ALL)
	@Fetch(FetchMode.JOIN)
	public Warehouse getWarehouse() {
		return warehouse;
	}
	public void setWarehouse(Warehouse warehouse) {
		this.warehouse = warehouse;
	}
    @JsonSerialize(using = CustomDateSerializer.class)
	public Date getInTime() {
		return inTime;
	}
	public void setInTime(Date inTime) {
		this.inTime = inTime;
	}
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getOutTime() {
		return outTime;
	}
	public void setOutTime(Date outTime) {
		this.outTime = outTime;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	@JoinColumn(name = "tagId",unique=true)
	@ManyToOne(fetch=FetchType.LAZY,cascade = CascadeType.ALL)
	@Fetch(FetchMode.JOIN)
	public TagDetails getTagDetails() {
		return tagDetails;
	}
	public void setTagDetails(TagDetails tagDetails) {
		this.tagDetails = tagDetails;
	}
	
	@Column(name = "cost")
	public double getCost() {
		return cost;
	}
	public void setCost(double d) {
		this.cost = d;
	}
}
