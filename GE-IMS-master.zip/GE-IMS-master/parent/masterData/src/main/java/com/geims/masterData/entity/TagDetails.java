package com.geims.masterData.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.geims.masterData.config.CustomDateSerializer;


@Entity
@Table(name = "tagDetails")
public class TagDetails {
	private int id;
	private String rfid;
	private Item item;
	private Date manufactureDate;
	private Date expiryDate;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name = "rfid",unique=true)
	public String getRfid() {
		return rfid;
	}
	public void setRfid(String rfid) {
		this.rfid = rfid;
	}
	
	@JoinColumn(name = "itemId")
	@ManyToOne(fetch=FetchType.LAZY,cascade = CascadeType.ALL)
	@Fetch(FetchMode.JOIN)
	public Item getItem() {
		return item;
	}
	public void setItem(Item item) {
		this.item = item;
	}
	
	@Column(name = "mfgDate")
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getManufactureDate() {
		return manufactureDate;
	}
	public void setManufactureDate(Date manufactureDate) {
		this.manufactureDate = manufactureDate;
	}
	
	@Column(name = "expDate")
	@JsonSerialize(using = CustomDateSerializer.class)
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
}
