package com.geims.masterData.service;

import java.util.List;

import com.geims.masterData.entity.Category;
import com.geims.masterData.entity.Warehouse;
import com.geims.masterData.vo.AssemblyVo;
import com.geims.masterData.vo.ReceiveItem;
import com.geims.masterData.vo.ReceiveSearchParameters;
import com.geims.masterData.vo.ReceiveVo;
import com.geims.masterData.vo.SendSearchResult;
import com.geims.masterData.vo.SendVo;

public interface MasterDataService {
	public SendVo updateAndSend(ReceiveVo receiveVo);
	public void updateItem(ReceiveItem item);
	public void updateWarehouse(Warehouse warehouse);
	public void updateTagDetails(ReceiveVo receiveVo);
	public void updateCategory(Category category);
	public SendSearchResult send(ReceiveSearchParameters param);
	public List<Double> updateInventoryItem(AssemblyVo assemblyVo);
	public boolean isAuthenticated(String username, String password);
	public void logoutUser(String username);
}
