package com.geims.masterData.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.geims.masterData.dao.CategoryDao;
import com.geims.masterData.dao.InventoryDetailsDao;
import com.geims.masterData.dao.ItemDao;
import com.geims.masterData.dao.TagDetailsDao;
import com.geims.masterData.dao.UserDao;
import com.geims.masterData.dao.WarehouseDao;
import com.geims.masterData.entity.Category;
import com.geims.masterData.entity.InventoryDetails;
import com.geims.masterData.entity.Item;
import com.geims.masterData.entity.TagDetails;
import com.geims.masterData.entity.Warehouse;
import com.geims.masterData.entity.User;
import com.geims.masterData.service.MasterDataService;
import com.geims.masterData.vo.AssemblyVo;
import com.geims.masterData.vo.PartNumberVo;
import com.geims.masterData.vo.ReceiveItem;
import com.geims.masterData.vo.ReceiveSearchParameters;
import com.geims.masterData.vo.ReceiveVo;
import com.geims.masterData.vo.SendSearchResult;
import com.geims.masterData.vo.SendVo;

@Service
public class MasterDataServiceImpl implements MasterDataService {

	@Autowired
	private WarehouseDao warehouseDao;

	@Autowired
	private TagDetailsDao tagDetailsDao;

	@Autowired
	private InventoryDetailsDao inventoryDetailsDao;

	@Autowired
	private ItemDao itemDao;

	@Autowired
	private CategoryDao categoryDao;
	
	@Autowired
	private UserDao userDao;

	@Override
	public SendVo updateAndSend(ReceiveVo receiveVo) {
		// TODO Auto-generated method stub
		SendVo send = new SendVo();
		InventoryDetails temp = new InventoryDetails();
		temp.setInTime(receiveVo.getInTime());
		temp.setOutTime(receiveVo.getOutTime());
		if (temp.getOutTime() != null) {
			if (temp.getInTime().getTime() > temp.getOutTime().getTime()) {
				temp.setStatus(1);
			} else {
				temp.setStatus(0);
			}
		} else {
			temp.setStatus(1);
		}
		temp.setTagDetails(tagDetailsDao.findByRfid(receiveVo.getRfid()));
		temp.setWarehouse(warehouseDao.findById(receiveVo.getWarehouseId()));
		temp.setCost(receiveVo.getCost());
		inventoryDetailsDao.save(temp);
		send.setInventoryDetails(temp);
		return send;
	}

	@Override
	public void updateItem(ReceiveItem item) {
		// TODO Auto-generated method stub
		Item temp = new Item();
		temp.setId(item.getId());
		temp.setItemName(item.getItemName());
		temp.setCategory(categoryDao.findById(item.getCategoryId()));
		itemDao.save(temp);
	}

	@Override
	public void updateWarehouse(Warehouse warehouse) {
		// TODO Auto-generated method stub
		warehouseDao.save(warehouse);
	}

	@Override
	public void updateTagDetails(ReceiveVo receiveVo) {
		// TODO Auto-generated method stub
		TagDetails temp = new TagDetails();
		temp.setExpiryDate(receiveVo.getExpiryDate());
		temp.setManufactureDate(receiveVo.getMfgDate());
		temp.setRfid(receiveVo.getRfid());
		temp.setItem(itemDao.findById(receiveVo.getItemId()));
		tagDetailsDao.save(temp);

	}

	@Override
	public void updateCategory(Category category) {
		// TODO Auto-generated method stub
		Category temp = categoryDao.findById(category.getId());
		if (temp != null) {
			temp.setCategory(category.getCategory());
			categoryDao.save(temp);
		} else {
			temp = new Category();
			temp.setCategory(category.getCategory());
			temp.setId(category.getId());
			categoryDao.save(temp);
		}
	}

	@Override
	public SendSearchResult send(ReceiveSearchParameters param) {
		// TODO Auto-generated method stub
		List<InventoryDetails> warehouseFilter = inventoryDetailsDao.findByWarehouse_Id(param.getWarehouseId());
		List<InventoryDetails> itemIdFilter = inventoryDetailsDao.findByWarehouse_Id(param.getPartNumber());
		List<InventoryDetails> itemNameFilter = inventoryDetailsDao.findByTagDetails_Item_ItemName(param.getItemName());
		List<InventoryDetails> categoryFilter = inventoryDetailsDao
				.findByTagDetails_Item_Category_Category(param.getCategory());
		List<InventoryDetails> costFilter = inventoryDetailsDao.findByCost(param.getCost());
		List<InventoryDetails> all = inventoryDetailsDao.findAll();
		if (warehouseFilter != null)
			all.retainAll(warehouseFilter);
		if (itemIdFilter != null)
			all.retainAll(itemIdFilter);
		if (itemNameFilter != null)
			all.retainAll(itemNameFilter);
		if (categoryFilter != null)
			all.retainAll(categoryFilter);
		if (costFilter != null)
			all.retainAll(costFilter);
		SendSearchResult data = new SendSearchResult();
		data.setInventoryList(all);
		return data;
	}

	@Override
	public List<Double> updateInventoryItem(AssemblyVo assemblyVo) {
		List<Double> costList=new ArrayList<Double>();
		int count = 0;
		for (PartNumberVo partVo : assemblyVo.getPartNumberList()) {
			List<InventoryDetails> listInv = inventoryDetailsDao.findByTagDetails_Item_Id(partVo.getPartNumber());
			Integer qty = partVo.getRecomendedQuantity();
			double totalItemCost=0.0;
			for(int i =0;i<listInv.size();i++){
				if(listInv.get(i).getStatus() == 1)
					count++;
			}
			if(count<qty)
				return null;
			for(int i=0;i<listInv.size();i++){
				if(qty == 0)
					break;
				if(listInv.get(i).getStatus()==1){
					qty--;
					totalItemCost+=listInv.get(i).getCost();
					listInv.get(i).setStatus(0);
					inventoryDetailsDao.save(listInv.get(i));
				}
			}
			costList.add(totalItemCost);		
		}
		return costList;
	}
	
	@Override
	public boolean isAuthenticated(String username, String password){
		User user = userDao.findByUserName(username);
		if(password.equals(user.getPassword())){
			user.setStatus(1);
			userDao.save(user);
			return true;
		}
		else{
			user.setStatus(0);
			userDao.save(user);
			return false;
		}
	}
	
	@Override
	public void logoutUser(String username){
		User user = userDao.findByUserName(username);
		if(user != null){
			user.setStatus(0);
			userDao.save(user);
		}
	}
}

