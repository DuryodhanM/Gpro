package com.geims.masterData.vo;

import java.util.List;

public class AssemblyVo {
	private String assemblyName;
	private List<PartNumberVo> partNumberList;
	public String getAssemblyName() {
		return assemblyName;
	}
	public void setAssemblyName(String assemblyName) {
		this.assemblyName = assemblyName;
	}
	public List<PartNumberVo> getPartNumberList() {
		return partNumberList;
	}
	public void setPartNumberList(List<PartNumberVo> partNumberList) {
		this.partNumberList = partNumberList;
	}
	
}
