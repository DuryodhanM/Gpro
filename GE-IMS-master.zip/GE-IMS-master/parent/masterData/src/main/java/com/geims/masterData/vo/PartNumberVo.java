package com.geims.masterData.vo;

public class PartNumberVo {
	private int partNumber;
	private String category;
	private int recomendedQuantity;
	/*private List<String> warehouseName;
	private List<Integer> quantity;*/
	private String message;
	private int status;
	private int totalQuantity;
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public int getPartNumber() {
		return partNumber;
	}
	public void setPartNumber(int partNumber) {
		this.partNumber = partNumber;
	}
	public int getRecomendedQuantity() {
		return recomendedQuantity;
	}
	public void setRecomendedQuantity(int recomendedQuantity) {
		this.recomendedQuantity = recomendedQuantity;
	}
	/*public List<String> getWarehouseName() {
		return warehouseName;
	}
	public void setWarehouseName(List<String> warehouseName) {
		this.warehouseName = warehouseName;
	}
	public List<Integer> getQuantity() {
		return quantity;
	}
	public void setQuantity(List<Integer> quantity) {
		this.quantity = quantity;
	}*/
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
}
