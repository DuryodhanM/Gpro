package com.geims.masterData.vo;

public class ReceiveCategory {

}
