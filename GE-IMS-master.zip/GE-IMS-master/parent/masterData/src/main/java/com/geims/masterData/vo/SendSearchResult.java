package com.geims.masterData.vo;

import java.util.List;

import com.geims.masterData.entity.InventoryDetails;

public class SendSearchResult {
	private List<InventoryDetails> inventoryList;

	public List<InventoryDetails> getInventoryList() {
		return inventoryList;
	}

	public void setInventoryList(List<InventoryDetails> inventoryList) {
		this.inventoryList = inventoryList;
	}
}
