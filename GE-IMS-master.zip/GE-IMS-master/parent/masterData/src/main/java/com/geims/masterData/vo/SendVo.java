package com.geims.masterData.vo;

import com.geims.masterData.entity.InventoryDetails;

public class SendVo {
	private InventoryDetails inventoryDetails;

	public InventoryDetails getInventoryDetails() {
		return inventoryDetails;
	}

	public void setInventoryDetails(InventoryDetails inventoryDetails) {
		this.inventoryDetails = inventoryDetails;
	}
}
